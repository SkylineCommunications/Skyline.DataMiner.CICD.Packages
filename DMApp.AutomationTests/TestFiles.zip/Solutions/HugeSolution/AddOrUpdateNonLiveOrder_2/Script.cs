/*
****************************************************************************
*  Copyright (c) 2020,  Skyline Communications NV  All Rights Reserved.    *
****************************************************************************

By using this script, you expressly agree with the usage terms and
conditions set out below.
This script and all related materials are protected by copyrights and
other intellectual property rights that exclusively belong
to Skyline Communications.

A user license granted for this script is strictly for personal use only.
This script may not be used in any way by anyone without the prior
written consent of Skyline Communications. Any sublicensing of this
script is forbidden.

Any modifications to this script by the user are only allowed for
personal use and within the intended purpose of the script,
and will remain the sole responsibility of the user.
Skyline Communications will not be responsible for any damages or
malfunctions whatsoever of the script resulting from a modification
or adaptation by the user.

The content of this script is confidential information.
The user hereby agrees to keep this confidential information strictly
secret and confidential and not to disclose or reveal it, in whole
or in part, directly or indirectly to any person, entity, organization
or administration without the prior written consent of
Skyline Communications.

Any inquiries can be addressed to:

	Skyline Communications NV
	Ambachtenstraat 33
	B-8870 Izegem
	Belgium
	Tel.	: +32 51 31 35 69
	Fax.	: +32 51 31 01 29
	E-mail	: info@skyline.be
	Web		: www.skyline.be
	Contact	: Ben Vandenberghe

****************************************************************************
Revision History:

DATE		VERSION		AUTHOR			COMMENTS

18/03/2021	1.0.0.1		TRE, Skyline	Updated edit rights for Non-MCR users
06/04/2021	1.0.0.2		TRE, Skyline	Allow multiple file selection.
****************************************************************************
*/

namespace AddOrUpdateNonLiveOrder_2
{
	using System;
	using System.IO;
	using System.Threading.Tasks;
	using Skyline.DataMiner.Automation;
	using Skyline.DataMiner.DeveloperCommunityLibrary.InteractiveAutomationToolkit;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.IngestExport;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.IngestExport.Aspera;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.IngestExport.Export;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.IngestExport.FolderCreation;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.IngestExport.Ingest;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.IngestExport.Project;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.IngestExport.Transfer;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Notifications;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Order;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.LoadingScreens;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.NonLive;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;
	using ExceptionDialog = Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.Reports.ExceptionDialog;
	using Type = Skyline.DataMiner.DeveloperCommunityLibrary.YLE.IngestExport.Type;

	internal class Script : IDisposable
	{
		private InteractiveController app;

		private LoadNonLiveOrderFormDialog loadNonLiveOrderFormDialog;
		private MainDialog nonLiveOrderForm;
		private NonLiveRejectionDialog rejectionDialog;
		private Helpers helpers;

		private int timeOutResult;
		private bool disposedValue;

		public void Run(Engine engine)
		{
			var scriptTask = Task.Factory.StartNew(() =>
			{
				try
				{
					Initialize(engine);

					loadNonLiveOrderFormDialog = new LoadNonLiveOrderFormDialog(helpers, LoadNonLiveOrderFormDialog.ScriptAction.AddOrUpdate);

					if (loadNonLiveOrderFormDialog.Execute()) ShowNonLiveOrderForm();
					else app.Run(loadNonLiveOrderFormDialog);
				}
				catch (InteractiveUserDetachedException)
				{
					// Do Nothing
				}
				catch (ScriptAbortException)
				{
					// Do Nothing
				}
				catch (Exception e)
				{
					if (timeOutResult != -1)
					{
						engine.Log("Run|Something went wrong: " + e);
						ShowExceptionDialog(e);
					}
				}
				finally
				{
					Dispose();
				}
			});

			timeOutResult = Task.WaitAny(new[] { scriptTask }, new TimeSpan(9, 59, 40));
		}

		private void Initialize(Engine engine)
		{
			engine.Timeout = TimeSpan.FromHours(10);
			//engine.ShowUI();

			helpers = new Helpers(engine, "AddOrUpdateNonLiveOrder");
			app = new InteractiveController(engine);
		}

		private void ShowNonLiveOrderForm()
		{
			nonLiveOrderForm = loadNonLiveOrderFormDialog.NonLiveOrderFormDialog;
			nonLiveOrderForm.CancelButton.Pressed += Dialog_CancelButton_Pressed;
			nonLiveOrderForm.BookButton.Pressed += Dialog_SaveOrBookButton_Pressed;
			nonLiveOrderForm.SaveButton.Pressed += Dialog_SaveOrBookButton_Pressed;
			nonLiveOrderForm.RejectOrderButton.Pressed += Dialog_RejectOrderButton_Pressed;

			if (app.IsRunning) app.ShowDialog(nonLiveOrderForm);
			else app.Run(nonLiveOrderForm);
		}

		private void ShowExceptionDialog(Exception exception)
		{
			ExceptionDialog exceptionDialog = new ExceptionDialog((Engine)helpers.Engine, exception);
			exceptionDialog.OkButton.Pressed += (sender, args) => helpers.Engine.ExitSuccess("Something went wrong during the creation of the new Order.");
			if (app.IsRunning) app.ShowDialog(exceptionDialog); else app.Run(exceptionDialog);
		}

		private void ShowMessageDialog(string message, string title) 
		{
			MessageDialog dialog = new MessageDialog(helpers.Engine, message) { Title = title };
			dialog.OkButton.Pressed += (sender, args) => helpers.Engine.ExitSuccess(message);

			if (app.IsRunning) app.ShowDialog(dialog);
			else app.Run(dialog);
		}

		private void Dialog_CancelButton_Pressed(object sender, EventArgs e)
		{
			helpers.NonLiveOrderManager.CancelNonLiveOrder(nonLiveOrderForm.NonLiveOrder, loadNonLiveOrderFormDialog.UserInfo.User);

			ShowMessageDialog("Order successfully canceled", "Cancel Non Live Order");
		}

		private void Dialog_RejectOrderButton_Pressed(object sender, EventArgs e)
		{
			rejectionDialog = new NonLiveRejectionDialog(helpers.Engine);
			rejectionDialog.CancelButton.Pressed += RejectionDialog_CancelButton_Pressed;
			rejectionDialog.RejectButton.Pressed += RejectionDialog_RejectButton_Pressed;

			app.ShowDialog(rejectionDialog);
		}

		private void RejectionDialog_RejectButton_Pressed(object sender, EventArgs e)
		{
			if (!rejectionDialog.IsValid()) return;

			rejectionDialog.UpdateNonLiveOrder(nonLiveOrderForm.NonLiveOrder);

			helpers.NonLiveOrderManager.SetNonLiveOrderToChangeRequested(nonLiveOrderForm.NonLiveOrder, loadNonLiveOrderFormDialog.UserInfo.User);

			ShowMessageDialog("Order successfully rejected", "Reject Non Live Order");
		}

		private void RejectionDialog_CancelButton_Pressed(object sender, EventArgs e)
		{
			app.ShowDialog(nonLiveOrderForm);
		}

		private void Dialog_SaveOrBookButton_Pressed(object sender, EventArgs e)
		{
			var action = (Button)sender == nonLiveOrderForm.BookButton ? OrderAction.Book : OrderAction.Save;

			if (!nonLiveOrderForm.UpdateValidity(action))
			{
				nonLiveOrderForm.ValidationLabel.Text = "Form can't be saved. Make sure all required fields are correctly configured.";
				return;
			}
		
			var nonLiveOrder = nonLiveOrderForm.EditOrder ? nonLiveOrderForm.NonLiveOrder : GenerateNewNonLiveOrder(nonLiveOrderForm.Type);

			nonLiveOrderForm.MainSection.UpdateNonLiveOrder(nonLiveOrder);

			SetNonLiveOrderState(action, nonLiveOrder);

			if (TryAddOrUpdateNonLiveOrder(nonLiveOrder))
			{
				ShowMessageDialog("Order successfully " + (action == OrderAction.Book ? "booked" : "saved"), (action == OrderAction.Book ? "Book" : "Save") + " Non Live Order");
			}
			else
			{
				ShowMessageDialog("Fail","Unable to add or update Non Live Order");
			}
		}

		private static void SetNonLiveOrderState(OrderAction action, NonLiveOrder nonLiveOrder)
		{
			if (action == OrderAction.Book)
			{
				if (nonLiveOrder.State == State.WorkInProgress && nonLiveOrder.IsAssignedToSomeone) return; 
			
				nonLiveOrder.State = State.Submitted;
			}
			else
			{
				nonLiveOrder.State = State.Preliminary;
			}
		}

		private static NonLiveOrder GenerateNewNonLiveOrder(Type type)
		{
			switch (type)
			{
				case Type.Export:
					return new Export();
				case Type.Import:
					return new Ingest();
				case Type.IplayFolderCreation:
					return new FolderCreation();
				case Type.IplayWgTransfer:
					return new Transfer();
				case Type.NonInterplayProject:
					return new Project();
				case Type.AsperaOrder:
					return new Aspera();
				default:
					throw new ArgumentException($"{type} is an unsupported type of Non Live Order");
			}
		}

		private bool TryAddOrUpdateNonLiveOrder(NonLiveOrder nonLiveOrder)
		{
			if (helpers.NonLiveOrderManager.AddOrUpdateNonLiveOrder(nonLiveOrder, loadNonLiveOrderFormDialog.UserInfo.User, out var dmaAndTicketId))
			{
				switch (nonLiveOrderForm.Type)
				{
					case Type.Export:
						var exportOrder = (Export)nonLiveOrder;
						string validFolderName = dmaAndTicketId.Replace('/', '_');
						string folderPath = Path.Combine(Constants.TicketAttachmentsFolderPath, validFolderName);

						exportOrder.UpdateExportFilesToSpecificDirectory(helpers, folderPath);
						break;

					case Type.IplayFolderCreation when !nonLiveOrderForm.EditOrder:
						NotificationManager.SendNonLiveOrderIplayFolderCreationMail(helpers, nonLiveOrder);
						break;

					case Type.IplayWgTransfer:
						helpers.NonLiveUserTaskManager.AddOrUpdateUserTasks(nonLiveOrder);
						break;

					default:
						// Unsupported non-live type
						break;
				}

				if (nonLiveOrderForm.EditOrder) NotificationManager.SendNonLiveOrderEditedMail(helpers, nonLiveOrder);
				else if (nonLiveOrderForm.Type != Type.IplayFolderCreation)
				{
					//Avoid sending two emails for IPlayFolderCreation
					NotificationManager.SendNonLiveOrderCreationMail(helpers, nonLiveOrder);
				}
				else
				{
					//do nothing
				}


				return true;
			}
			else
			{
				return false;
			}
		}

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
					helpers.Dispose();
				}

				disposedValue = true;
			}
		}

		public void Dispose()
		{
			// Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
			Dispose(disposing: true);
			GC.SuppressFinalize(this);
		}
	}
}


