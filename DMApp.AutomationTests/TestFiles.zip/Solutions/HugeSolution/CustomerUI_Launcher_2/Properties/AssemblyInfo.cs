using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("FinnishBroadcastingCompany_CustomerUI_Launcher_3")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Skyline Communications")]
[assembly: AssemblyProduct("FinnishBroadcastingCompany_CustomerUI_Launcher_3")]
[assembly: AssemblyCopyright("Copyright © Skyline Communications")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("AE5D86EA-795E-4BF4-9068-58F3F01BA06C")]
[assembly: AssemblyVersion("1.0.0.0")]
