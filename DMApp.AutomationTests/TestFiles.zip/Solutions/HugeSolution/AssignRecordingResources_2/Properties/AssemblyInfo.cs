using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("AssignRecordingResources_2")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Skyline Communications")]
[assembly: AssemblyProduct("AssignRecordingResources_2")]
[assembly: AssemblyCopyright("Copyright © Skyline Communications")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("A09BD0C0-047F-4253-818B-FB8BB5D1A624")]
[assembly: AssemblyVersion("1.0.0.0")]
