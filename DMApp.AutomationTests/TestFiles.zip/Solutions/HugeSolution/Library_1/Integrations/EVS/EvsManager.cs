﻿namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Integrations.EVS
{
    using Skyline.DataMiner.Automation;
    using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Configuration;
    using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Exceptions;
    using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;
    using Skyline.DataMiner.EVS.EVS_IPD_VIA.Messages;
    using Skyline.DataMiner.EVS.EVS_IPD_VIA.Model;
    using Skyline.DataMiner.Library.Automation;
    using Skyline.DataMiner.Library.Common;
    using Skyline.DataMiner.Library.Common.InterAppCalls.CallBulk;
    using Skyline.DataMiner.Library.Common.InterAppCalls.Shared;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Service = Service.Service;

    public class EvsManager
	{
		private readonly Dictionary<Type, Type> executorMap = new Dictionary<Type, Type>
		{
			{ typeof(AddOrUpdateRecordingSessionResult), typeof(AddOrUpdateRecordingSessionExecutor) },
			{ typeof(DeleteRecordingSessionResult), typeof(DeleteRecordingSessionExecutor) },
		};

		private readonly List<Type> knownTypes = new List<Type> 
		{
			typeof(AddOrUpdateRecordingSession),
			typeof(AddOrUpdateRecordingSessionResult),
			typeof(DeleteRecordingSession),
			typeof(DeleteRecordingSessionResult),
			typeof(RecordingSession),
			typeof(Metadata),
			typeof(List<Metadata>),
			typeof(Metadata[]),
			typeof(Dictionary<string, string>),
			typeof(ReturnAddress)
		};

		private readonly Helpers helpers;
		private readonly IDmsElement element;

		public EvsManager(Helpers helpers)
		{
			this.helpers = helpers ?? throw new ArgumentNullException(nameof(helpers));

			var dms = helpers.Engine.GetDms();
			element = dms.GetElements().FirstOrDefault(x => x.Protocol.Name.Equals(EvsIpdViaProtocol.Name) && x.State == ElementState.Active) ?? throw new ElementByProtocolNotFoundException(EvsIpdViaProtocol.Name);
		}

		public List<Recorder> GetRecorderNames()
		{
			var recorderTable = element.GetTable(EvsIpdViaProtocol.RecordersTable.TablePid);
			return recorderTable.GetData().Select(x => new Recorder { Instance = x.Key, Name = Convert.ToString(x.Value[EvsIpdViaProtocol.RecordersTable.Idx.RecordersName]) }).ToList();
		}

		public void AddOrUpdateRecordingSession(Service recordingService, RecordingSession recordingSession)
		{
			helpers.Log(nameof(EvsManager), nameof(AddOrUpdateRecordingSession), $"EVS Id for service: {recordingService.Name} => {recordingService.EvsId}");

			var commands = InterAppCallFactory.CreateNew();
			commands.ReturnAddress = new ReturnAddress(element.AgentId, element.Id, 9000001);
			commands.Messages.Add(new AddOrUpdateRecordingSession
			{
				RecordingSession = recordingSession
			});

			var responses = commands.Send(Engine.SLNetRaw, element.AgentId, element.Id, 9000000, TimeSpan.FromSeconds(30), knownTypes);
			foreach (var response in responses)
			{
				if (!response.TryExecute(helpers, recordingService, executorMap, out var responseMessage))
                {
					helpers.Log(nameof(EvsManager), nameof(AddOrUpdateRecordingSession), $"Handling response message failed");
				}
			}

			helpers.Log(nameof(EvsManager), nameof(AddOrUpdateRecordingSession), $"EVS Recording Session Id: {recordingService.EvsId}");
		}

		public bool DeleteRecordingSession(Service recordingService, string recordingSessionId)
        {
			try
            {
				var commands = InterAppCallFactory.CreateNew();
				commands.ReturnAddress = new ReturnAddress(element.AgentId, element.Id, 9000001);
				commands.Messages.Add(new DeleteRecordingSession
				{
					RecordingSessionsId = recordingSessionId
				});

				helpers.Log(nameof(EvsManager), nameof(DeleteRecordingSession), $"Deleting recording session {recordingSessionId}");

				commands.Send(Engine.SLNetRaw, element.AgentId, element.Id, 9000000, knownTypes);
				recordingService.EvsId = null;

				return true;
            }
			catch (Exception e)
            {
				helpers.Log(nameof(EvsManager), nameof(DeleteRecordingSession), $"Unable to delete Recording Session due to: {e}");
				return false;
            }
		}

		/// <summary>
		/// Retrieves the metadata labels from the Profile Fields table.
		/// </summary>
		/// <returns>All labels from the Profile Fields table.</returns>
		public List<Label> GetMetadataLabels()
        {
			var profileFieldsTable = element.GetTable(EvsIpdViaProtocol.ProfileFieldsTable.TablePid);

			return profileFieldsTable.GetData().Values.Select(x => new Label 
			{
				Key = Convert.ToString(x[1]),
				Name = Convert.ToString(x[2]),
				Type = Convert.ToString(x[3]),
				Required = Convert.ToBoolean(x[4]),
				ProfileFqn = Convert.ToString(x[7]),
				ProfileName = Convert.ToString(x[8])
			}).ToList();
        }
	}

	public class Recorder
    {
		public string Instance { get; set; }

		public string Name { get; set; }
    }

	public class Label
    {
		public string Name { get; set; }

		public string ProfileName { get; set; }

		public string Key { get; set; }

		public string ProfileFqn { get; set; }

		public bool Required { get; set; }

		public string Type { get; set; }
    }
}