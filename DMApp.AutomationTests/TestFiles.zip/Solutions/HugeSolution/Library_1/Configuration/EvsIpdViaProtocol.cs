﻿namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Configuration
{
    public static class EvsIpdViaProtocol
	{
		public static readonly string Name = "EVS IPD-VIA";

		public static class RecordersTable
		{
			public static readonly int TablePid = 1000;

			public static class Idx
			{
				public static readonly int RecordersName = 1;
			}
		}

		public static class RecordingSessionsTable
        {
			public static readonly int TablePid = 1400;

			public static readonly int RecordingSessionsName = 1402;

			public static class Idx
            {
				public static readonly int RecordingSessionsInstance = 0;

				public static readonly int RecordingSessionsName = 1;

				public static readonly int RecordingSessionsRecorderName = 5;
			}
		}

		public static class ProfileFieldsTable
        {
			public static readonly int TablePid = 1900;
        }
	}
}
