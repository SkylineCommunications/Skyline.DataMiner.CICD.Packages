﻿namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Configuration
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    internal static class Agents
    {
        public static readonly Dictionary<int, string> AgentIDs = new Dictionary<int, string> {
            { 665, "slc-h42-g06.skyline.local" },
            { 127601, "dataminer-test.yleisradio.fi" },
            { 127602, "dataminer-test.yleisradio.fi" },
            { 127609, "dataminer-test.yleisradio.fi" },
            { 127603, "dataminer.ylead.fi" },
            { 127604, "dataminer.ylead.fi" },
            { 127608, "dataminer.ylead.fi" },
        };
    }
}
