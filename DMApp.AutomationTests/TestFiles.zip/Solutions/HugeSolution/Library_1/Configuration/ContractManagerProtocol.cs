﻿using Skyline.DataMiner.Library;
using System.Collections.Generic;

namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Configuration
{
    public static class ContractManagerProtocol
    {
        public const string ProtocolName = "Finnish Broadcasting Company Contract Manager";

        public const int UsersGroupTableID = 3000;
        public const int GroupId = 0;
        public const int GroupNameIdx = 1;
        public const int CompanyIdx = 11;
        public const int SportsIdx = 12;
        public const int McrIdx = 13;
        public const int GroupCustomNameIdx = 14;
        public const int FilterInternalItemsIdx = 24;
        public const int ConfigureTemplatesIdx = 25;
        public const int NewsIdx = 32;
        public const int SwapResourcesIdx = 33;

        public static readonly Dictionary<int, string> UserGroupParamsIDX = new Dictionary<int, string> {
            { CompanyIdx, "Company" },
            { SportsIdx, "Sports" },
            { McrIdx, "MCR" },
            { GroupCustomNameIdx, "Custom Name" },
            { FilterInternalItemsIdx, "Filter Internal Items" },
            { ConfigureTemplatesIdx, "Configure Templates" },
            { NewsIdx, "News" },
            { SwapResourcesIdx, "Swap Resources" }
        };

        public const int UsersTableID = 14000;
        public const int UsersID = 0;
        public const int UsersNameIDX = 1;
        public const int UsersEmailIDX = 3;
        public const int ConfirmationByOperatorIDX = 4;
        public const int RejectionByOperatorIDX = 5;
        public const int CompletionByDataminerIDX = 6;
        public const int CompletionWithErrorByDataminerIDX = 7;
        public const int CancellationByCustomerIDX = 8;
        public const int CancellationByOperatorIDX = 9;
        public const int CancellationByIntegrationIDX = 10;
        public const int NloReassignedByOperatorIDX = 11;
        public const int NloRejectionByOperatorIDX = 12;
        public const int NloCompletionByDataminerIDX = 13;
        public const int NloCancellationByOperatorIDX = 14;
        public const int NloWorkInProgressByOperatorIDX = 15;
        public const int ServicesBookedIDX = 17;
        public const int ServicesBookedByIntegrationsIDX = 18;
        public const int NloEditedByOperatorIDX = 19;
        public const int NloCreationByOperatorIDX = 20;
        public const int NloIplayFolderCreationByOperatorIDX = 21;
        public const int UsersPhoneIDX = 22;
        public const int UnableToBookRecurringVizrem = 23;

        public static readonly Dictionary<int, string> NotificationParamsIDX = new Dictionary<int, string> {
            { UsersEmailIDX, "Email" },
            { UsersPhoneIDX, "Phone" },
            { ConfirmationByOperatorIDX, "Live Order Confirmation by Operator Notification" },
            { RejectionByOperatorIDX, "Live Order Rejection by Operator Notification" },
            { CompletionByDataminerIDX, "Live Order Completion by DataMiner Notification" },
            { CompletionWithErrorByDataminerIDX, "Live Order Completion with Errors by DataMiner Notification" },
            { CancellationByCustomerIDX, "Live Order Cancellation by Customer Notification" },
            { CancellationByOperatorIDX, "Live Order Cancellation by Operator Notification" },
            { CancellationByIntegrationIDX, "Live Order Cancellation by Integration Notification" },
            { NloReassignedByOperatorIDX, "Non Live Order Reassigned by Operator" },
            { NloRejectionByOperatorIDX, "Non Live Order Rejection by Operator" },
            { NloCompletionByDataminerIDX, "Non Live Order Completion by DataMiner" },
            { NloCancellationByOperatorIDX, "Non Live Order Cancellation by Operator" },
            { NloWorkInProgressByOperatorIDX, "Non Live Order Work in Progress by Operator" },
            { ServicesBookedIDX, "Live Order Services Booked Notification" },
            { ServicesBookedByIntegrationsIDX, "Live Order Services Booked by Integrations Notification" },
            { NloEditedByOperatorIDX, "Non Live Order Edited by Operator" },
            { NloCreationByOperatorIDX, "Non Live Order Creation by Operator" },
            { NloIplayFolderCreationByOperatorIDX, "Non Live Order Iplay Folder Creation by Operator" },
            { UnableToBookRecurringVizrem, "Unable to Book Recurring Vizrem Order" }
        };
    }
}