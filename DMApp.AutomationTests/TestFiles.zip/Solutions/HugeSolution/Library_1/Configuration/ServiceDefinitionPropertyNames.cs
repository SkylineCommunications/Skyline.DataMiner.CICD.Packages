﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Configuration
{
	public static class ServiceDefinitionPropertyNames
	{
		public const string DiagramHashCode = "Diagram Hash Code";
	}
}
