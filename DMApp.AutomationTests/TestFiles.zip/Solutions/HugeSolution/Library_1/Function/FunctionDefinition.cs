﻿namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Function
{
    using Skyline.DataMiner.Automation;
    using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Exceptions;
    using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.DataMinerInterface;
    using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;
    using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Profile;
    using Skyline.DataMiner.Library.Solutions.SRM;
    using Skyline.DataMiner.Library.Solutions.SRM.Model;
    using Skyline.DataMiner.Net.Messages;
    using Skyline.DataMiner.Net.Messages.SLDataGateway;
    using Skyline.DataMiner.Net.ResourceManager.Objects;
    using Skyline.DataMiner.Net.SRM.Capabilities;
    using Skyline.DataMiner.Net.Time;
    using System;
    using System.Collections.Generic;
	using System.Diagnostics;
	using System.Linq;
    using Service = Service.Service;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Resources;

	public class FunctionDefinition
	{
		public Guid Id { get; set; }

		public string Name { get; set; }

		/// <summary>
		/// The label assigned to this function definition in the service definition.
		/// </summary>
		public string Label { get; set; }

		public int ConfigurationOrder { get; internal set; }

		public string Options { get; internal set; }

		public string ResourcePool { get; internal set; }

        public bool IsHidden { get; internal set; }

        public ProfileDefinition ProfileDefinition { get; internal set; }

        public Dictionary<Guid, ProfileDefinition> InterfaceProfileDefinitions { get; internal set; }

        public List<Guid> Children { get; internal set; }

		/// <summary>
		/// Indicates if manual resource selection is allowed for this node in the service definition.
		/// Note that this is only applicable when retrieved via the service definition.
		/// </summary>
		public bool IsManualResourceSelectionAllowed { get; internal set; }

		public static FunctionDefinition DummyFunctionDefinition()
        {
            return new FunctionDefinition
            {
                Id = Guid.Empty,
                Name = "Dummy",
                Label = "Dummy",
                ConfigurationOrder = 0,
                IsHidden = true,
                IsManualResourceSelectionAllowed = false,
                ProfileDefinition = ProfileDefinition.DummyProfileDefinition(),
                InterfaceProfileDefinitions = new Dictionary<Guid, ProfileDefinition>(),
                Children = new List<Guid>()
			};
        }

        public YleEligibleResourceContext GetEligibleResourceContext(Helpers helpers, DateTime start, DateTime end, Guid? serviceToIgnoreGuid = null, int? functionToIgnoreNodeId = null, IEnumerable<ProfileParameter> capabilities = null)
		{
			capabilities = capabilities ?? new List<ProfileParameter>();

			var resourcePool = DataMinerInterface.ResourceManager.GetResourcePools(helpers, new ResourcePool { Name = ResourcePool })?.FirstOrDefault() ?? throw new ResourcePoolNotFoundException(ResourcePool);

			var resourceCapabilityUsages = new List<ResourceCapabilityUsage>();
			foreach (var parameter in capabilities)
			{
				var resourceCapabilityUsage = new ResourceCapabilityUsage { CapabilityProfileID = parameter.Id };
				switch (parameter.Type)
				{
					case ParameterType.Number:
						resourceCapabilityUsage.RequiredRangePoint = Convert.ToDouble(parameter.Value);
						break;
					case ParameterType.Discrete:
						resourceCapabilityUsage.RequiredDiscreet = Convert.ToString(parameter.Value);
						break;
					default:
						resourceCapabilityUsage.RequiredString = Convert.ToString(parameter.Value);
						break;
				}

				resourceCapabilityUsages.Add(resourceCapabilityUsage);
			}

			var context = new YleEligibleResourceContext(Label, resourcePool.GUID)
			{
				ContextId = Guid.NewGuid(),
				TimeRange = new Net.Time.TimeRangeUtc(start.ToUniversalTime(), end.ToUniversalTime()),
				ResourceFilter = ResourceExposers.PoolGUIDs.Contains(resourcePool.GUID),
				RequiredCapabilities = resourceCapabilityUsages
			};

			if (serviceToIgnoreGuid.HasValue && functionToIgnoreNodeId.HasValue)
			{
				context.ReservationIdToIgnore = new Net.ReservationInstanceID(serviceToIgnoreGuid.Value);
				context.NodeIdToIgnore = functionToIgnoreNodeId.Value;
			}

			return context;
		}

		/// <summary>
		/// Gets all Resources that are available on the DMA for this function definition.
		/// </summary>
		public IEnumerable<Resource> GetAllResources(Helpers helpers)
		{
			ResourcePool resourcePool = DataMinerInterface.ResourceManager.GetResourcePools(helpers, new ResourcePool { Name = ResourcePool }).FirstOrDefault();
			if (resourcePool == null) throw new ResourcePoolNotFoundException(ResourcePool);

			return DataMinerInterface.ResourceManager.GetResources(helpers, FunctionResourceExposers.PoolGUIDs.Contains(resourcePool.GUID)).OrderBy(x => x.Name);
		}

        /// <summary>
        /// Returns a list of profile parameters for this function definition with their default value assigned.
        /// </summary>
        /// <param name="skipDtrParameters">Indicates if DTR parameters should be skipped.</param>
        /// <returns>The list of profile parameters.</returns>
        public List<ProfileParameter> GetProfileParametersWithDefaultValue(bool skipDtrParameters = true)
        {
            var profileParameters = ProfileDefinition.ProfileParameters.ToList();
            foreach (var profileParameter in profileParameters)
            {
                if (skipDtrParameters && profileParameter.Name.StartsWith("_")) continue;

                switch (profileParameter.Type)
                {
                    case ParameterType.Discrete:
                        profileParameter.Value = profileParameter.Discreets.FirstOrDefault()?.InternalValue;
                        break;

                    case ParameterType.Number:
                        profileParameter.Value = profileParameter.RangeMin;
                        break;

                    default:
                        profileParameter.Value = String.Empty;
                        break;
                }

                if (profileParameter.DefaultValue != null)
                {
                    if (profileParameter.DefaultValue.Type == Net.Profiles.ParameterValue.ValueType.Double &&
                        profileParameter.DefaultValue.DoubleValue >= profileParameter.RangeMin &&
                        profileParameter.DefaultValue.DoubleValue <= profileParameter.RangeMax)
                    {
                        profileParameter.Value = profileParameter.DefaultValue.DoubleValue;
                    }
                    else if (profileParameter.DefaultValue.Type == Net.Profiles.ParameterValue.ValueType.String &&
                        profileParameter.DefaultValue.StringValue != null)
                    {
                        profileParameter.Value = profileParameter.DefaultValue.StringValue;
                    }
                }
            }

            return profileParameters;
        }
	}
}