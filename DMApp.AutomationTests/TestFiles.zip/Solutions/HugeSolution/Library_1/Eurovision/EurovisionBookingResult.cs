namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Eurovision
{
	public class EurovisionBookingResult
	{
		public bool IsSuccessful { get; set; }

		public string Id { get; set; }

		public string ErrorMessage { get; set; }
	}
}