namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Eurovision
{
	public interface IEurovisionObject { }
}