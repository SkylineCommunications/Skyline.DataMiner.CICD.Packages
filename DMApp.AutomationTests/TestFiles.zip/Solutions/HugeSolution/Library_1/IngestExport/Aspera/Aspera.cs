﻿namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.IngestExport.Aspera
{
    using Newtonsoft.Json;
    using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;

    public class Aspera : NonLiveOrder
    {
        public Aspera()
        {
            AsperaType = default(string);
            Workgroup = default(string);
            SendersEmails = default(string[]);
            ValidDays = default(int);
            ImportDepartment = default(string);
            NameofTheShare = default(string);
            PurposeAndUsage = default(string);
            ParticipantsEmailAddress = default(string[]);
            AdditionalInfo = default(string);

        }

        [JsonProperty]
        public override IngestExport.Type OrderType => IngestExport.Type.AsperaOrder;

        [JsonIgnore]
        public override string ShortDescription => $"{OrderDescription} - {IngestExport.Type.AsperaOrder.GetDescription()}";

        [JsonProperty]
        public string AsperaType { get; set; }

        [JsonProperty]
        public string Workgroup { get; set; }

        [JsonProperty]
        public string[] SendersEmails { get; set; }

        [JsonProperty]
        public double ValidDays { get; set; }

        [JsonProperty]
        public string ImportDepartment { get; set; }

        [JsonProperty]
        public string NameofTheShare { get; set; }

        [JsonProperty]
        public string PurposeAndUsage { get; set; }

        [JsonProperty]
        public string[] ParticipantsEmailAddress { get; set; }

        [JsonProperty]
        public string AdditionalInfo { get; set; }
    }
}