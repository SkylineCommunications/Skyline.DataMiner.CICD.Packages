﻿namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Controllers
{
	using System;
	using System.Collections.Generic;
	using System.Diagnostics;
	using System.Linq;
	using Skyline.DataMiner.DeveloperCommunityLibrary.InteractiveAutomationToolkit;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Configuration;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Contracts;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Exceptions;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Exceptions.ServiceDefinition;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Function;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Order;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Order.Recurrence;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Profile;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Resources;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Service;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Service.AutoGeneration;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Service.ResourceAssignment;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.ServiceDefinition;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.Order;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.Service;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;
	using Skyline.DataMiner.Utils.FBC.Integrations;
	using Service = Service.Service;

	public abstract class OrderController
    {
        protected readonly Helpers helpers;
        protected readonly Order order;
        private readonly OrderSection orderSection;
        protected readonly UserInfo userInfo;
        protected readonly IEnumerable<Service> controlledServicesWhereOrderRefersTo;
        protected readonly LiveVideoOrder liveVideoOrder;

        protected readonly Dictionary<string, DisplayedService> cachedReceptionServices = new Dictionary<string, DisplayedService>(); // Cached by Service Definition Name
        protected readonly Dictionary<string, DisplayedService> cachedBackupReceptionServices = new Dictionary<string, DisplayedService>(); // Cached by Service Definition Name
        protected readonly Dictionary<Guid, DisplayedService> cachedSharedSourceServices = new Dictionary<Guid, DisplayedService>(); // Cached by Service ID

        protected IReadOnlyDictionary<VirtualPlatformType, IReadOnlyList<ServiceDefinition>> serviceDefinitions;
        protected IReadOnlyDictionary<VirtualPlatformType, IReadOnlyList<ServiceDefinition>> allowedServiceDefinitions;

        protected readonly Dictionary<Service, ServiceController> serviceControllers = new Dictionary<Service, ServiceController>();

        public OrderController(Helpers helpers, Order order, UserInfo userInfo, OrderSection orderSection = null, IEnumerable<Service> controlledServicesWhereOrderRefersTo = null)
		{
			this.helpers = helpers ?? throw new ArgumentNullException(nameof(helpers));
			this.order = order ?? throw new ArgumentNullException(nameof(order));
			this.userInfo = userInfo ?? throw new ArgumentNullException(nameof(userInfo));
			this.orderSection = orderSection;
			this.controlledServicesWhereOrderRefersTo = controlledServicesWhereOrderRefersTo ?? new Service[0];

            if (order.Status != YLE.Order.Status.Preliminary && order.Status != YLE.Order.Status.PlannedUnknownSource)
            {
                liveVideoOrder = new LiveVideoOrder(helpers, order); // Only create a LiveVideoOrder for orders that are already booked
            }

			ConfirmSharedRoutingServicesAreValid(this.controlledServicesWhereOrderRefersTo.ToList());
		}

		protected virtual void InitializeCachedServices()
		{
            InitializeCachedReceptionService(order.SourceService);

            foreach (var service in OrderManager.FlattenServices(order.SourceService.Children))
			{
				switch (service.Definition.VirtualPlatformServiceType)
				{
                    case VirtualPlatformType.Reception:
                        throw new InvalidOperationException("VP Reception should already have been handled");

                    case VirtualPlatformType.Recording:
					case VirtualPlatformType.Destination:
					case VirtualPlatformType.Transmission:
                    case VirtualPlatformType.VizremFarm:
                    case VirtualPlatformType.VizremStudio:
						if (service.BackupType == BackupType.None)
						{
							CachedSourceChildServices[service.Definition.VirtualPlatformServiceType].Add(new List<DisplayedService> { service as DisplayedService });
						}
						break;
					default:
						// No cache required as the service is not being displayed.
						break;
				}
			}
		}

        protected void InitializeCachedReceptionService(Service service)
        {
            if (service.BackupType == BackupType.None)
            {
                if (service.IsSharedSource)
                {
                    cachedSharedSourceServices.Add(service.Id, service as DisplayedService);
                }
                else
                {
                    cachedReceptionServices.Add(service.Definition.Name, service as DisplayedService);
                }
            }
            else
            {
                cachedBackupReceptionServices.Add(service.Definition.Name, service as DisplayedService);
            }
        }

        public event EventHandler UploadJsonButtonPressed;

        public event EventHandler<Service> UploadSynopsisButtonPressed;

        public event EventHandler SourceChanged;

        public event EventHandler ValidationRequired;

        public event EventHandler UiDisableRequired;

        public event EventHandler UiEnableRequired;

        public void InvokeUiDisable()
		{
            UiDisableRequired?.Invoke(this, EventArgs.Empty);
		}

        public void InvokeUiEnable()
        {
            UiEnableRequired?.Invoke(this, EventArgs.Empty);
        }

        protected void OnUploadSynopsisButtonPressed(Service service)
        {
            UploadSynopsisButtonPressed?.Invoke(this, service);
        }

        public void InvokeValidationRequired()
        {
            Log(nameof(InvokeValidationRequired), "Invoking order validation");
            ValidationRequired?.Invoke(this, EventArgs.Empty);
        }

        public event EventHandler<Service> BookEurovisionService;

        public OrderSection Section => orderSection;

        protected void OnUploadJsonButtonPressed()
		{
            UploadJsonButtonPressed?.Invoke(this, EventArgs.Empty);
		}

        protected void OnBookEurovisionService(Service service)
        {
            BookEurovisionService?.Invoke(this, service);
        }

        protected abstract IReadOnlyDictionary<VirtualPlatformType, List<List<DisplayedService>>> CachedSourceChildServices { get; }

        protected abstract IEnumerable<DisplayedService> CachedServices { get; }

        public Guid OrderId => order.Id;

        /// <summary>
		/// Loops over all services in the Order and updates the Order start and end time accordingly.
		/// </summary>
		public virtual void HandleServiceTimeUpdate()
        {
			if (order.AllServices.Any(x => !x.IsSharedSource))
            {
				order.Start = order.AllServices.Where(s => !s.IsSharedSource).Select(s => s.Start).Min();
				Log(nameof(HandleServiceTimeUpdate), "Setting order start time to " + order.Start);

				order.End = order.AllServices.Where(s => !s.IsSharedSource).Select(s => s.End).Max();
				Log(nameof(HandleServiceTimeUpdate), "Setting order end time to " + order.End);
			}

            var endpointServices = order.AllServices.Where(x => !x.Children.Any());
            foreach (var endpointService in endpointServices)
            {
                order.UpdateAutoGeneratedServiceTimings(helpers, endpointService);
            }
        }

        public void CopyOrderPlasmaIdToServices()
        {
            foreach (var service in order.AllServices)
            {
                if (service.RecordingConfiguration.CopyPlasmaIdFromOrder)
                {
                    service.RecordingConfiguration.PlasmaIdForArchive = order.PlasmaId;
                }
            }

            InvokeValidationRequired();
        }

        public void Dispose()
		{
            orderSection.Dispose();
        }

        public abstract void HandleSelectedResourceUpdate(Service service, Function function);

        protected virtual void InitializeDisplayedOrder()
        {
            order.SelectableSecurityViewIds = GetSelectableCompanyViewIds();
            order.SetSelectableUserGroups(userInfo.AllUserGroups.Where(u => u.Company == userInfo.Contract.Company));
            order.SetSelectableCompanies(userInfo.AllCompanies);
            
            order.AvailableSourceServices = allowedServiceDefinitions[order.SourceService.Definition.VirtualPlatformServiceType].Select(x => x.VirtualPlatformServiceName.GetDescription()).Distinct().ToList();
            order.AvailableSourceServiceDescriptions = allowedServiceDefinitions[order.SourceService.Definition.VirtualPlatformServiceType].Where(x => x.VirtualPlatform == order.SourceService.Definition.VirtualPlatform).Select(x => x.Description).ToList();

            order.AvailableBackupSourceServices = allowedServiceDefinitions[order.SourceService.Definition.VirtualPlatformServiceType].Select(x => x.VirtualPlatformServiceName.GetDescription()).Distinct().ToList();
            var availableBackupSourceServiceDescriptions = order.BackupSourceService == null ? new List<string>() : allowedServiceDefinitions[order.SourceService.Definition.VirtualPlatformServiceType].Where(x => x.VirtualPlatform == order.BackupSourceService.Definition.VirtualPlatform).Select(x => x.Description).ToList();
            order.AvailableBackupSourceServiceDescriptions = availableBackupSourceServiceDescriptions;

            if (!order.RecurringSequenceInfo.Recurrence.IsConfigured)
            {
                order.RecurringSequenceInfo.Recurrence.RecurrenceRepeat.Day = (DaysOfTheWeek)(1 << ((int)order.Start.DayOfWeek + 6) % 7);
                order.RecurringSequenceInfo.Recurrence.RecurrenceRepeat.SelectableUmpteenthDayOfTheMonthOption = new RecurrenceRepeat.SelectableOption
                {
                    DisplayValue = $"Monthly on day {order.Start.Day}",
                    UmpteethDay = order.Start.Day
                };

                order.RecurringSequenceInfo.Recurrence.RecurrenceRepeat.SelectableUmpteenthOccurrenceOfWeekDayOfTheMonthOption = new RecurrenceRepeat.SelectableOption
                {
                    DisplayValue = GetUmpteenthWeekDayOfTheMonthOption(),
                    Day = order.Start.DayOfWeek.ToString().GetEnumValue<DaysOfTheWeek>(),
                    UmpteethDay = (int)Math.Floor(order.Start.Day / 7.0) + 1
                };
            }
		}

        private string GetUmpteenthWeekDayOfTheMonthOption()
        {
            var umpteenthOccurrenceOfWeekDayOfTheMonth = (int)Math.Floor(order.Start.Day / 7.0) + 1;

            string postfix;
            switch (umpteenthOccurrenceOfWeekDayOfTheMonth)
            {
                case 1:
                    postfix = "st";
                    break;
                case 2:
                    postfix = "nd";
                    break;
                case 3:
                    postfix = "rd";
                    break;
                case 4:
                case 5:
                    postfix = "th";
                    break;
                default:
                    postfix = "error";
                    break;
            }

            return $"Monthly on the {umpteenthOccurrenceOfWeekDayOfTheMonth}{postfix} {order.Start.DayOfWeek.ToString()}";
        }

		internal Service ServiceTypeDropDown_Changed(object sender, DropDown.DropDownChangedEventArgs e)
        {
            var newService = controlledServicesWhereOrderRefersTo.Distinct().SingleOrDefault(x => x.Definition?.Description == e.Selected);
            var existingSourceService = order.Sources.SingleOrDefault(s => s.BackupType == BackupType.None) ?? throw new ServiceNotFoundException($"Unable to find an main source service in order {order.Name}", true);

            if (newService != null && newService.IsSharedSource)
            {
                if (!newService.IsBooked) Service.CopyProfileParameterValuesFromPreviousToNewFunction(existingSourceService, newService);
                order.ChangeOrderMainSourceService(existingSourceService, newService);
            }
            else
            {
                var previousExistingService = controlledServicesWhereOrderRefersTo.Distinct().SingleOrDefault(x => x.Definition?.Description == e.Previous);
                if (newService == null || previousExistingService == null) return null;

                if (!newService.IsBooked) Service.CopyProfileParameterValuesFromPreviousToNewFunction(previousExistingService, newService);

                if (newService.Definition.VirtualPlatformServiceType == VirtualPlatformType.Reception) order.ChangeOrderMainSourceService(previousExistingService, newService);
                else order.ChangeOrderService(previousExistingService, newService);
            }

			return newService;
		}

        public void HandleProfileParameterUpdate(Service service, Function function, ProfileParameter changedProfileParameter)
        {
            // Cover all actions that need to happen accross the order when a service profile parameter value changes

			if (service.Equals(order.SourceService) && (changedProfileParameter.Id == ProfileParameterGuids.VideoFormat || ProfileParameterGuids.IsAudioChannelProfileParameter(changedProfileParameter.Id)))
			{
				foreach (var child in OrderManager.FlattenServices(service.Children))
				{
					SetValuesBasedOnSourceService(child, order.SourceService);
				}
			}

			bool remoteGraphicsChangedOnGraphicsProcessingService = changedProfileParameter.Id == ProfileParameterGuids.RemoteGraphics && service.Definition.VirtualPlatform == VirtualPlatform.GraphicsProcessing;
			if (remoteGraphicsChangedOnGraphicsProcessingService)
			{
				// If the value of the Remote Graphics profile parameter on the graphics processing service is manually changed by a user, we should update the child endpoint services of the gfx proc service accordingly

				foreach (var child in OrderManager.FlattenServices(service.Children))
				{
					var remoteGraphicsParameter = child.Functions.SelectMany(f => f.Parameters).SingleOrDefault(p => p.Id == ProfileParameterGuids.RemoteGraphics);
					if (remoteGraphicsParameter is null) continue;

					remoteGraphicsParameter.Value = changedProfileParameter.Value;
				}
			}
        }

        /// <summary>
        /// Gets the Audio Channel Configuration of the Source service from the given child service.
        /// </summary>
        /// <returns>The AudioChannelConfiguration property of the Source Service.</returns>
        /// <exception cref="ServiceNotFoundException"/>
        public AudioChannelConfiguration GetSourceAudioChannelConfiguration()
        {
            var sourceService = order.Sources.SingleOrDefault(s => s.BackupType == BackupType.None);
            if (sourceService == null) throw new ServiceNotFoundException(BackupType.None);

            return sourceService.AudioChannelConfiguration;
        }

		protected virtual void SubscribeToUi()
		{
			if (orderSection == null) return;
           
            orderSection.SourceChanged += Section_SourceChanged;
            orderSection.SourceDescriptionChanged += Section_SourceDescriptionChanged;
            orderSection.SourceServiceSectionAdded += (sourceServiceSection, addedSourceServiceSection) => RegisterServiceController(addedSourceServiceSection);

            // General information section subscriptions
            orderSection.GeneralInfoSection.NameFocusLost += (s, e) => OrderNameFocusLost(e);
            orderSection.GeneralInfoSection.StartChanged += (s, e) => OrderStartTimeChanged(e);
            orderSection.GeneralInfoSection.StartNowChanged += (s, e) => OrderStartNowChanged(e);
            orderSection.GeneralInfoSection.EndChanged += (s, e) => OrderEndTimeChanged(e);
            orderSection.GeneralInfoSection.SecurityViewIdsChanged += (s, selectedSecurityViewIds) => order.SetSecurityViewIds(selectedSecurityViewIds);
            orderSection.GeneralInfoSection.DisplayedPropertyChanged += (s, e) => order.SetPropertyValue(helpers, e.PropertyName, e.PropertyValue);
            orderSection.GeneralInfoSection.BillableCompanyChanged += (s, e) => order.BillingInfo.BillableCompany = e;
            orderSection.GeneralInfoSection.CustomerCompanyChanged += (s, e) => order.BillingInfo.CustomerCompany = e;
            orderSection.GeneralInfoSection.PlasmaIdChanged += (s, plasmaIdToSet) =>
            {
                order.PlasmaId = plasmaIdToSet;
                CopyOrderPlasmaIdToServices();
                InvokeValidationRequired();
            };

            // General information recurrence section subscriptions
            orderSection.GeneralInfoSection.RecurrenceSection.RecurrenceCheckBoxChanged += RecurrenceSection_RecurrenceCheckBoxChanged;
            orderSection.GeneralInfoSection.RecurrenceSection.RepeatEveryAmountChanged += (s, frequency) => order.RecurringSequenceInfo.Recurrence.RecurrenceFrequency.Frequency = frequency;
            orderSection.GeneralInfoSection.RecurrenceSection.RepeatEveryUnitChanged += (s, unit) => order.RecurringSequenceInfo.Recurrence.RecurrenceFrequency.FrequencyUnit = unit;
            orderSection.GeneralInfoSection.RecurrenceSection.RepeatTypeChanged += (s, repeatType) => order.RecurringSequenceInfo.Recurrence.RecurrenceRepeat.RepeatType = repeatType;
            orderSection.GeneralInfoSection.RecurrenceSection.UmpteenthDayOfTheMonthChanged += (s, umpteenthDayOfTheMonth) => order.RecurringSequenceInfo.Recurrence.RecurrenceRepeat.UmpteenthDayOfTheMonth = umpteenthDayOfTheMonth;
            orderSection.GeneralInfoSection.RecurrenceSection.DayOfTheWeekChanged += (s, dayOfTheWeek) => order.RecurringSequenceInfo.Recurrence.RecurrenceRepeat.Day = dayOfTheWeek;
            orderSection.GeneralInfoSection.RecurrenceSection.UmpteenthOccurrenceOfWeekDayOfTheMonthChanged += (s, umpteenthOccurrenceOfWeekDayOfTheMonthChanged) => order.RecurringSequenceInfo.Recurrence.RecurrenceRepeat.UmpteenthOccurrenceOfWeekDayOfTheMonth = umpteenthOccurrenceOfWeekDayOfTheMonthChanged;
            orderSection.GeneralInfoSection.RecurrenceSection.EndingTypeChanged += (s, endingType) => order.RecurringSequenceInfo.Recurrence.RecurrenceEnding.EndingType = endingType;
            orderSection.GeneralInfoSection.RecurrenceSection.EndingDateTimeChanged += (s, endingDateTime) => order.RecurringSequenceInfo.Recurrence.RecurrenceEnding.EndingDateTime = endingDateTime;
            orderSection.GeneralInfoSection.RecurrenceSection.AmountOfRepeatsChanged += (s, amountOfRepeats) => order.RecurringSequenceInfo.Recurrence.RecurrenceEnding.AmountOfRepeats = amountOfRepeats;

            orderSection.ServiceSelectionSectionAdded += (s, e) => RegisterServiceSelectionSection(e);
        }

		protected void RecurrenceSection_RecurrenceCheckBoxChanged(object sender, bool isChecked)
        {
            order.NamePostFix = isChecked ? $" [{order.Start.ToFinnishDateString()}]" : string.Empty;

			order.RecurringSequenceInfo.Recurrence.IsConfigured = isChecked;
			order.RecurringSequenceInfo.Name = order.ManualName;
			order.RecurringSequenceInfo.Recurrence.StartTime = order.Start;
		}

        protected virtual void InitializeServiceControllers()
        {
            if (orderSection is null) return;

            RegisterServiceController(orderSection.SourceServiceSection);
            
            foreach (var childServiceSection in orderSection.SourceChildSections)
            {
                RegisterServiceSelectionSection(childServiceSection);
                foreach (var linkedRecordingServiceSection in childServiceSection.ChildSections) RegisterServiceSelectionSection(linkedRecordingServiceSection);
            }
        }

        protected virtual void RegisterServiceController(ServiceSection e)
        {
            if (serviceControllers.Any(x => x.Value.Section.Equals(e))) return;

            InvokeUiDisable();

            // TODO: should a controller be made for shared source that were created in other orders? => no, these services should not change

            Log(nameof(RegisterServiceController), $"Creating Service Controller for Service: {e.Service.Name} ({e.Service.Definition.VirtualPlatform}.{e.Service.Definition.Description}) BackupType {e.Service.BackupType}");

            var serviceResourceAssignmentHandler = ResourceAssignmentHandler.Factory(helpers, e.Service, order);
            ServiceController serviceController = new ServiceController(helpers, e.Service, this, GetSelectableCompanyViewIds(), e, serviceResourceAssignmentHandler, userInfo);
            serviceControllers.Add(e.Service, serviceController);

            e.Service.SetAvailableVirtualPlatformNames(allowedServiceDefinitions[e.Service.Definition.VirtualPlatformServiceType].Select(x => x.VirtualPlatformServiceName.GetDescription()));
            e.Service.SetAvailableServiceDescriptions(allowedServiceDefinitions[e.Service.Definition.VirtualPlatformServiceType].Where(x => x.VirtualPlatform == e.Service.Definition.VirtualPlatform).Select(x => x.Description));

            InvokeUiEnable();
        }

        protected void RegisterServiceSelectionSection(CollapsableServiceSelectionSection section)
        {
            section.ServiceVirtualPlatformNameChanged += Section_ServiceVirtualPlatformNameChanged;
            section.ServiceDescriptionChanged += Section_ServiceDescriptionChanged;
            section.DeleteButtonPressed += ServiceSelectionSection_DeleteButtonPressed;

            RegisterServiceController(section.ServiceSection);
        }

        private void OrderNameFocusLost(string name)
        {
            order.ManualName = name;
            order.RecurringSequenceInfo.Name = name;

            foreach (var recordingService in order.AllServices.Where(x => x.Definition.VirtualPlatform == VirtualPlatform.Recording))
            {
                if (!String.IsNullOrWhiteSpace(recordingService.RecordingConfiguration.RecordingName)) continue;
                recordingService.RecordingConfiguration.RecordingName = name;
            }

            InvokeValidationRequired();
        }

        protected void OrderStartNowChanged(bool startNow)
		{
            order.StartNow = startNow;

            OrderStartTimeChanged(DateTime.Now.RoundToMinutes());
		}

        protected virtual void OrderStartTimeChanged(DateTime orderStartTime)
        {
            InvokeUiDisable();

            TimeSpan startTimeDifference = orderStartTime.Subtract(order.Start);

            order.Start = orderStartTime;

            if (order.End < orderStartTime) order.End = orderStartTime;

            foreach (var service in order.AllServices.Concat(CachedServices))
            {
                if (service.IsSharedSource) continue;

                if (serviceControllers.TryGetValue(service, out var serviceController))
                {
                    serviceController.StartDateTimePicker_Changed(this, orderStartTime);
                    serviceController.EndDateTimePicker_Changed(this, order.End);
                }
                else
                {
                    service.Start = orderStartTime;
                    service.End = order.End;
                }      
            }

            order.NamePostFix = order.RecurringSequenceInfo.Recurrence.IsConfigured ? $" [{order.Start.ToFinnishDateString()}]" : order.NamePostFix;

            UpdateRecurrence(startTimeDifference);

            InvokeValidationRequired();

            InvokeUiEnable();
        }

        private void UpdateRecurrence(TimeSpan startTimeDifference)
        {
            if (order.RecurringSequenceInfo.RecurrenceAction == RecurrenceAction.New)
            {
                order.RecurringSequenceInfo.Recurrence.StartTime = order.Start;
            }

            if (order.RecurringSequenceInfo.RecurrenceAction != RecurrenceAction.ThisOrderOnly)
            {
                order.RecurringSequenceInfo.Recurrence.StartTime += startTimeDifference;
                order.RecurringSequenceInfo.Recurrence.RecurrenceRepeat.Day |= (DaysOfTheWeek)(1 << ((int)order.Start.DayOfWeek + 6) % 7);
                order.RecurringSequenceInfo.Recurrence.RecurrenceRepeat.SelectableUmpteenthDayOfTheMonthOption = new RecurrenceRepeat.SelectableOption
                {
                    DisplayValue = $"Monthly on day {order.Start.Day}",
                    UmpteethDay = order.Start.Day
                };

                order.RecurringSequenceInfo.Recurrence.RecurrenceRepeat.SelectableUmpteenthOccurrenceOfWeekDayOfTheMonthOption = new RecurrenceRepeat.SelectableOption
                {
                    DisplayValue = GetUmpteenthWeekDayOfTheMonthOption(),
                    Day = order.Start.DayOfWeek.ToString().GetEnumValue<DaysOfTheWeek>(),
                    UmpteethDay = (int)Math.Floor(order.Start.Day / 7.0) + 1
                };
            }
        }

        protected virtual void OrderEndTimeChanged(DateTime orderEndTime)
		{
            InvokeUiDisable();

			var previousOrderEnd = order.End;

			order.End = orderEndTime;
			if (order.Start > orderEndTime) order.Start = orderEndTime;

			foreach (var service in order.AllServices.Concat(CachedServices))
            {
                if (service.IsSharedSource) continue;
                if (service.EurovisionBookingDetails?.Type == Integrations.Eurovision.Type.NewsEvent) continue;
                if (service.EurovisionBookingDetails?.Type == Integrations.Eurovision.Type.ProgramEvent) continue;

                if (!order.ShouldBeRunning)
                {
                    if (serviceControllers.TryGetValue(service, out var serviceController))
                    {
                        serviceController.StartDateTimePicker_Changed(this, order.Start);
                    }
					else
					{
                        service.Start = order.Start;

                        Log(nameof(OrderEndTimeChanged), $"Set service {service.Name} start time to {service.Start.ToFullDetailString()} based on order start time");
					}
                }

                bool orderIsShorterThanService = orderEndTime < service.End;
                bool orderIsLongerThanServiceAndServiceEndShouldFollowOrderEnd = service.End == previousOrderEnd && orderEndTime > service.End;

                if (orderIsShorterThanService || orderIsLongerThanServiceAndServiceEndShouldFollowOrderEnd)
                {
                    if (serviceControllers.TryGetValue(service, out var serviceController))
                    {
                        serviceController.EndDateTimePicker_Changed(this, orderEndTime);
                    }
                    else
                    {
                        service.End = orderEndTime;

                        Log(nameof(OrderEndTimeChanged), $"Set service {service.Name} end time to {service.End.ToFullDetailString()} based on order end time");
                    }
                }

                bool routingServiceIsRunning = service.ShouldBeRunning && service.Definition.VirtualPlatform == VirtualPlatform.Routing;
                if (routingServiceIsRunning)
                {
                    var matrixOutputFunction = service.Functions.Single(f => f.Id == FunctionGuids.MatrixOutputSdi);
					
                    var occupyingServices = helpers.ResourceManager.GetOccupyingServices(matrixOutputFunction.Resource, service.StartWithPreRoll, service.EndWithPostRoll, order.Id, service.Name );

                    if (occupyingServices.Any())
					{
                        Log(nameof(OrderEndTimeChanged), $"Routing output resource {matrixOutputFunction.Resource.Name} has occupying services: '{string.Join(", ", occupyingServices.Select(os => os.ToString()))}' over {service.StartWithPreRoll.ToFullDetailString()} until {service.EndWithPostRoll.ToFullDetailString()}");
                        matrixOutputFunction.Resource = new OccupiedResource(matrixOutputFunction.Resource) { OccupyingServices = occupyingServices };
					}		
                }
            }

            InvokeValidationRequired();
            InvokeUiEnable();
        }

        protected void UpdateLiveVideoOrder()
        {
            if (liveVideoOrder == null) return;
            liveVideoOrder.Update();
        }

        private void Section_ServiceVirtualPlatformNameChanged(object sender, string newVirtualPlatformName)
        {
            CollapsableServiceSelectionSection serviceSelectionSection = (CollapsableServiceSelectionSection)sender;
            VirtualPlatformType virtualPlatformType = serviceSelectionSection.Service.Definition.VirtualPlatformServiceType;
            var possibleServiceDefinitions = allowedServiceDefinitions[virtualPlatformType].Where(x => x.VirtualPlatformServiceName.GetDescription() == newVirtualPlatformName);
            ServiceDefinition newServiceDefinition = possibleServiceDefinitions.FirstOrDefault(x => x.IsDefault) ?? possibleServiceDefinitions.FirstOrDefault();

            Log(nameof(Section_ServiceVirtualPlatformNameChanged), $"Selected Service Definition: {newServiceDefinition.Name}");

            ServiceSelectionSection_ServiceTypeChanged(serviceSelectionSection.Service, newVirtualPlatformName, newServiceDefinition.Description);
        }

        protected virtual void Section_ServiceDescriptionChanged(object sender, string newDescription)
        {
            CollapsableServiceSelectionSection serviceSelectionSection = (CollapsableServiceSelectionSection)sender;
            ServiceSelectionSection_ServiceTypeChanged(serviceSelectionSection.Service, serviceSelectionSection.SelectedVirtualPlatformName, newDescription);
        }

        protected abstract List<DisplayedService> GetCachedAlternativeServices(Service previousDisplayedService);

        protected void ServiceSelectionSection_ServiceTypeChanged(Service previousDisplayedService, string virtualPlatformName, string description)
        {
            Log(nameof(ServiceSelectionSection_ServiceTypeChanged), $"Virtual platform name {virtualPlatformName}, description {description}");

            var cachedAlternativeServices = GetCachedAlternativeServices(previousDisplayedService);

            DisplayedService newDisplayedService = cachedAlternativeServices.FirstOrDefault(x => x.Definition.VirtualPlatformServiceName.GetDescription() == virtualPlatformName && x.Definition.Description == description);
            if (newDisplayedService == null)
			{
				GenerateNewChildService(previousDisplayedService, virtualPlatformName, description, out newDisplayedService, out var newServiceDefinition);

                InitializeServiceBeforeBeingAdded(newDisplayedService, previousDisplayedService);

				cachedAlternativeServices.Add(newDisplayedService);

				Log(nameof(ServiceSelectionSection_ServiceTypeChanged), $"Created new service {newDisplayedService.Name}");
			}

			ReplaceService(previousDisplayedService, newDisplayedService);

            UpdateLiveVideoOrder();

            Log(nameof(ServiceSelectionSection_ServiceTypeChanged), $"Service {previousDisplayedService.Name} ({previousDisplayedService.Definition.VirtualPlatform}) was replaced with {newDisplayedService.Name} ({newDisplayedService.Definition.VirtualPlatform})");
        }

        protected abstract void GenerateNewChildService(Service previousDisplayedService, string virtualPlatformName, string description, out DisplayedService newDisplayedService, out ServiceDefinition newServiceDefinition);

		protected virtual void ReplaceService(Service existingService, DisplayedService newService)
		{
            LogMethodStart(nameof(ReplaceService), out var stopwatch);

            order.ReplaceService(existingService, newService);

            LogMethodCompleted(nameof(ReplaceService), stopwatch);
		}

		private void ServiceSelectionSection_DeleteButtonPressed(object sender, EventArgs e)
		{
			CollapsableServiceSelectionSection section = (CollapsableServiceSelectionSection)sender;
			var endpointService = section.Service as Service;
			
            DeleteEndpointService(endpointService);
		}

		protected virtual void DeleteEndpointService(Service sectionService)
		{
			List<DisplayedService> cachedAlternativeServices = CachedSourceChildServices[sectionService.Definition.VirtualPlatformServiceType].First(x => x.Contains(sectionService));
			Log(nameof(DeleteEndpointService), $"Removing cached source services: {String.Join(", ", cachedAlternativeServices.Select(x => (x.Name + " " + x.Definition.Name)))}");

			CachedSourceChildServices[sectionService.Definition.VirtualPlatformServiceType].Remove(cachedAlternativeServices);

			var parentService = order.AllServices.FirstOrDefault(x => x.Children.Contains(sectionService));
			parentService.Children.Remove(sectionService);

			Log(nameof(DeleteEndpointService), $"Removed {sectionService.Name} from the children of {parentService.Name}");

			// recursively remove all parents without children (e.g.: routing and processing)
			var serviceToBeChecked = parentService;
			while (!serviceToBeChecked.Children.Any())
			{
				parentService = order.AllServices.SingleOrDefault(x => x.Children.Contains(serviceToBeChecked));
				if (parentService is null) break;

				parentService.Children.Remove(serviceToBeChecked);

				Log(nameof(DeleteEndpointService), $"Removed {serviceToBeChecked.Name} from the children of {parentService.Name}, because {parentService.Name} has no children");

				serviceToBeChecked = parentService;
			}

			foreach (var serviceToRemove in cachedAlternativeServices)
			{
				serviceControllers.Remove(serviceToRemove);
			}

			UpdateLiveVideoOrder();

            InvokeUiEnable();
        }

        protected void Section_SourceChanged(object sender, string newSourceVirtualPlatformName)
        {
            InvokeUiDisable();

            Log(nameof(Section_SourceChanged), $"Source Dropdown changed: {newSourceVirtualPlatformName}");

            var sourceServiceDefinitions = allowedServiceDefinitions[VirtualPlatformType.Reception].Where(x => x.VirtualPlatformServiceName.GetDescription() == newSourceVirtualPlatformName).ToList();

            var defaultServiceDefinition = sourceServiceDefinitions.FirstOrDefault(x => x.IsDefault) ?? sourceServiceDefinitions.First();

            Log(nameof(Section_SourceChanged), $"Default Service Definition: {defaultServiceDefinition.Name}");

            UpdateOrderSourceService(orderSection.Source, defaultServiceDefinition.Description);

            Log(nameof(Section_SourceChanged), $"Setting allowed Source Service Descriptions to: {String.Join(", ", sourceServiceDefinitions.Select(s => s.Description).OrderBy(s => s))}");

            order.AvailableSourceServiceDescriptions = sourceServiceDefinitions.Select(s => s.Description).OrderBy(s => s).ToList();

            SourceChanged?.Invoke(this, EventArgs.Empty);

            InvokeValidationRequired();
            InvokeUiEnable();
        }

        protected virtual void Section_SourceDescriptionChanged(object sender, string e)
        {
            InvokeUiDisable();

            Log(nameof(Section_SourceDescriptionChanged), $"Source Description Dropdown changed: {e}");

            UpdateOrderSourceService(orderSection.Source, e);
        }

        protected void UpdateOrderSourceService(string source, string sourceDescription)
		{
			Log(nameof(UpdateOrderSourceService), $"Updating Source Service to {source} - {sourceDescription}");

			var serviceDefinition = allowedServiceDefinitions[order.SourceService.Definition.VirtualPlatformServiceType].FirstOrDefault(x => x.VirtualPlatformServiceName.GetDescription() == source && x.Description == sourceDescription) ?? throw new ServiceDefinitionNotFoundException($"Unable to find SD with VP name '{source}' and description '{sourceDescription}' between '{string.Join(", ", allowedServiceDefinitions[order.SourceService.Definition.VirtualPlatformServiceType].Select(sd => $"{sd.VirtualPlatformServiceName}({sd.Description})"))}'");

			if (!cachedReceptionServices.TryGetValue(serviceDefinition.Name, out var service))
			{
				service = new DisplayedService(helpers, serviceDefinition)
				{
					Start = order.Start,
					End = order.End,
				};

				if (order.IntegrationType != IntegrationType.None)
				{
					service.PreRoll = ServiceManager.GetPostRollDuration(serviceDefinition, order.IntegrationType);
					service.PostRoll = ServiceManager.GetPostRollDuration(serviceDefinition, order.IntegrationType);
				}

				service.AcceptChanges();

				cachedReceptionServices.Add(serviceDefinition.Name, service);
			}

			Log(nameof(UpdateOrderSourceService), $"Updating Source Service to {service.Name}");

			ReplaceService(order.SourceService, service);

			UpdateLiveVideoOrder();

			foreach (var child in OrderManager.FlattenServices(order.SourceService.Children))
			{
				SetValuesBasedOnSourceService(child, order.SourceService);
			}

            InvokeValidationRequired();
        }

		protected void SetValuesBasedOnSourceService(Service serviceToUpdate, Service sourceService)
		{
			if (!userInfo.Contract.IsVideoProcessingAllowed())
			{
				// If user contract does not allow video processing, video format profile parameter value should be copied to all relevant children to avoid generation of video processing services.

				Log(nameof(SetValuesBasedOnSourceService), $"User {userInfo.User.Name} contract {userInfo.Contract.Name} does not allow video processing. Copying video format from source to {serviceToUpdate.Name} required");

				var sourceVideoFormatProfileParameter = sourceService.Functions.SelectMany(f => f.Parameters).SingleOrDefault(pp => pp.Id == ProfileParameterGuids.VideoFormat);
				var childVideoFormatProfileParameter = serviceToUpdate.Functions.SelectMany(f => f.Parameters).SingleOrDefault(pp => pp.Id == ProfileParameterGuids.VideoFormat);

				if (sourceVideoFormatProfileParameter is null)
				{
					Log(nameof(SetValuesBasedOnSourceService), $"WARNING: Could not find profile parameter {sourceVideoFormatProfileParameter.Name} in source service {sourceService.Name} to copy its value to service {serviceToUpdate.Name}");
				}
				else if (childVideoFormatProfileParameter is null)
				{
					Log(nameof(SetValuesBasedOnSourceService), $"WARNING: Could not find profile parameter {childVideoFormatProfileParameter.Name} in service {serviceToUpdate.Name} to copy its value from source service {sourceService.Name}");
				}
				else
				{
					childVideoFormatProfileParameter.Value = sourceVideoFormatProfileParameter.Value;

					Log(nameof(SetValuesBasedOnSourceService), $"Copied source service {sourceService} profile parameter {sourceVideoFormatProfileParameter.Name} value {sourceVideoFormatProfileParameter.StringValue} to service {serviceToUpdate.Name}");
				}
			}
			
			if (!userInfo.Contract.IsAudioProcessingAllowed())
			{
				// If user contract does not allow audio processing, audio channel profile parameter values should be copied to all relevant children to avoid generation of audio processing services.
				serviceToUpdate.AudioChannelConfiguration.CopyFromSource(sourceService.AudioChannelConfiguration);
				serviceToUpdate.AudioChannelConfiguration.SetSourceOptions(sourceService.AudioChannelConfiguration.GetSourceOptions());
			}
			
			if (serviceToUpdate.Definition.Description.Equals("messi news", StringComparison.OrdinalIgnoreCase) && serviceToUpdate.IntegrationType == IntegrationType.None)
			{
				// Recording Messi News connected to a IP RX Vidigo source does not require routing

				bool sourceIsIpVidigoReception = sourceService.Definition.VirtualPlatform == VirtualPlatform.ReceptionIp && sourceService.Definition.Description == "Vidigo";

				serviceToUpdate.RequiresRouting = !sourceIsIpVidigoReception;

				Log(nameof(SetValuesBasedOnSourceService), $"Service {serviceToUpdate.Name} is a manual Messi News recording service, RequiresRouting property set to {serviceToUpdate.RequiresRouting}, based on if the source is IP Vidigo");
			}
		}

		public virtual void AddChildService(DisplayedService serviceToAdd)
		{
			if (serviceToAdd is null) throw new ArgumentNullException(nameof(serviceToAdd));

			InitializeServiceBeforeBeingAdded(serviceToAdd);

			CachedSourceChildServices[serviceToAdd.Definition.VirtualPlatformServiceType].Add(new List<DisplayedService> { serviceToAdd });
			order.SourceService.Children.Add(serviceToAdd);

			UpdateLiveVideoOrder();
		}

		protected virtual void InitializeServiceBeforeBeingAdded(DisplayedService serviceToAdd, Service replacedService = null)
		{
            serviceToAdd.RecordingConfiguration.RecordingName = order.Name;

            int amountOfMainServicesWithSameVirtualPlatformType = order.AllMainServices.Count(s => s.Definition.VirtualPlatformServiceType == serviceToAdd.Definition.VirtualPlatformServiceType) + 1;

            for (int i = 1; i <= amountOfMainServicesWithSameVirtualPlatformType; i++)
            {
                string potentialDisplayName = $"{serviceToAdd.Definition.VirtualPlatformServiceType.GetDescription()} {i}";

                bool displayNameIsAlreadyUsed = order.AllMainServices.Any(s => s.DisplayName == potentialDisplayName);
                bool displayNameIsUsedByReplacedService = replacedService != null && replacedService.DisplayName == potentialDisplayName;

                if (displayNameIsUsedByReplacedService || !displayNameIsAlreadyUsed)
                {
                    serviceToAdd.DisplayName = potentialDisplayName;
                    break;
                }
            }

            if (order.IntegrationType != IntegrationType.None)
			{
				serviceToAdd.PreRoll = ServiceManager.GetPreRollDuration(serviceToAdd.Definition, order.IntegrationType);
				serviceToAdd.PostRoll = ServiceManager.GetPostRollDuration(serviceToAdd.Definition, order.IntegrationType);
			}

			serviceToAdd.SetAvailableVirtualPlatformNames(allowedServiceDefinitions[serviceToAdd.Definition.VirtualPlatformServiceType].Select(x => x.VirtualPlatformServiceName.GetDescription()));
			serviceToAdd.SetAvailableServiceDescriptions(allowedServiceDefinitions[serviceToAdd.Definition.VirtualPlatformServiceType].Where(x => x.VirtualPlatform == serviceToAdd.Definition.VirtualPlatform).Select(x => x.Description));

			serviceToAdd.AcceptChanges();
		}

		protected void Section_AddChildService(VirtualPlatformType type)
        {
            if (order.SourceService == null || !allowedServiceDefinitions[type].Any()) return;

            // Description based
            var serviceDefinition = allowedServiceDefinitions[type].FirstOrDefault(x => x.IsDefault) ?? allowedServiceDefinitions[type].First();

            Log(nameof(Section_AddChildService), $"Adding child service with SD: {serviceDefinition.Name}");

            DisplayedService service = new DisplayedService(helpers, serviceDefinition)
            {
                Start = order.Start,
                End = order.End,
            };

            AddChildService(service);

            InvokeValidationRequired();
        }

        private Dictionary<string, int> GetSelectableCompanyViewIds()
        {
            var companyViewIds = new Dictionary<string, int> { { "MCR", userInfo.McrSecurityViewId } };

            foreach (var company in userInfo.AllCompanies.Distinct())
            {
                int companyViewId = userInfo.AllUserGroups.First(u => u.Company == company).CompanySecurityViewId;

                bool eventHasVisibilityRightsForThisCompany = order.Event != null && order.Event.SecurityViewIds.Contains(companyViewId);
                if (eventHasVisibilityRightsForThisCompany)
                {
                    companyViewIds.Add(company, companyViewId);
                }
            }

            return companyViewIds;
        }

        private void ConfirmSharedRoutingServicesAreValid(List<Service> servicesToExcludeFromConfirmation)
        {
            if (liveVideoOrder == null) return;
            if (!servicesToExcludeFromConfirmation.Any()) return;

            var serviceShownInUpdateService = order.AllServices.Intersect(servicesToExcludeFromConfirmation).Single(); // find the one service that is currently in the order

            foreach (var sharedRoutingService in liveVideoOrder.GetRoutingServicesUsedByMultipleChains())
            {
                if (servicesToExcludeFromConfirmation.Contains(sharedRoutingService.Service)) continue;

				if (sharedRoutingService.Parent.Service.Equals(serviceShownInUpdateService))
				{
                    // If the parent of the shared routing service is the service shown in the form,
                    // do not validate the input of the shared routing as this can be changed by swapping the output of service shown in the form
                    sharedRoutingService.MatrixOutputSdiIsValid = true;
				}
                else if (sharedRoutingService.Service.Children.Contains(serviceShownInUpdateService))
				{
                    // If the child of the shared routing service is the service shown in the form,
                    // do not validate the output of the shared routing as this can be changed by swapping the input of service shown in the form
                    sharedRoutingService.MatrixInputSdiIsValid = true;
                }
                else
				{
                    sharedRoutingService.MatrixInputSdiIsValid = true;
                    sharedRoutingService.MatrixOutputSdiIsValid = true;
                }
            }
        }

        protected void Log(string methodName, string message)
        {
            helpers?.Log(this.GetType().Name, methodName, message, order.Name);
        }

        protected void LogMethodStart(string methodName, out Stopwatch stopwatch)
        {
            helpers.LogMethodStart(this.GetType().Name, methodName, out stopwatch);
        }

        protected void LogMethodCompleted(string methodName, Stopwatch stopwatch)
        {
            helpers.LogMethodCompleted(this.GetType().Name, methodName, null, stopwatch);
        }
    }
}