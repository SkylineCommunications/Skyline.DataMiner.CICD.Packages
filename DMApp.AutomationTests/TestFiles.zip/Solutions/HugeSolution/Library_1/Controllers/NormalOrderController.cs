﻿namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Controllers
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Configuration;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Contracts;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Function;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Order;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Service;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.ServiceDefinition;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.Order;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.Service;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;
	using Skyline.DataMiner.Utils.FBC.Integrations;
	using Service = Service.Service;

	public class NormalOrderController : OrderController
    {
        private NormalOrderSection orderSection;

        private readonly IReadOnlyDictionary<VirtualPlatformType, List<List<DisplayedService>>> cachedSourceChildServices = new Dictionary<VirtualPlatformType, List<List<DisplayedService>>>
        {
            { VirtualPlatformType.Destination, new List<List<DisplayedService>>() },
            { VirtualPlatformType.Recording, new List<List<DisplayedService>>() },
            { VirtualPlatformType.Transmission, new List<List<DisplayedService>>() }
        };

        private readonly IReadOnlyDictionary<VirtualPlatformType, List<List<DisplayedService>>> cachedBackupSourceChildServices = new Dictionary<VirtualPlatformType, List<List<DisplayedService>>>
        {
            { VirtualPlatformType.Destination, new List<List<DisplayedService>>() },
            { VirtualPlatformType.Recording, new List<List<DisplayedService>>() },
            { VirtualPlatformType.Transmission, new List<List<DisplayedService>>() }
        };

        private IReadOnlyList<SharedSourceInfo> sharedSources;

        public NormalOrderController(Helpers helpers, Order order, UserInfo userInfo, NormalOrderSection orderSection = null, IEnumerable<Service> controlledServicesWhereOrderRefersTo = null) : base(helpers, order, userInfo, orderSection, controlledServicesWhereOrderRefersTo)
        {
            this.orderSection = orderSection;

            Initialize();
        }

        protected override IReadOnlyDictionary<VirtualPlatformType, List<List<DisplayedService>>> CachedSourceChildServices => cachedSourceChildServices;

        protected override IEnumerable<DisplayedService> CachedServices
        {
            get
            {
                IEnumerable<DisplayedService> services = new List<DisplayedService>(cachedReceptionServices.Select(x => x.Value));
                foreach (var kvp in cachedSourceChildServices)
                {
                    foreach (var cachedService in kvp.Value)
                    {
                        services = services.Concat(cachedService);
                    }
                }

                foreach (var kvp in cachedBackupSourceChildServices)
                {
                    foreach (var cachedService in kvp.Value)
                    {
                        services = services.Concat(cachedService);
                    }
                }

                return services.ToList();
            }
        }

        public override void HandleSelectedResourceUpdate(Service service, Function function)
        {
            LogMethodStart(nameof(HandleSelectedResourceUpdate), out var stopwatch);

            if (liveVideoOrder == null)
            {
                Log(nameof(HandleSelectedResourceUpdate), $"{nameof(liveVideoOrder)} is null");
                LogMethodCompleted(nameof(HandleSelectedResourceUpdate), stopwatch);
                return;
            }

            SetResourcesOnOtherServices(service, function);

            ConditionalSetFixedTieLineOverrideProperty(service, function);

            HandleAudioProcessingServiceChanges(service);


            LogMethodCompleted(nameof(HandleSelectedResourceUpdate), stopwatch);
        }

        private void SetResourcesOnOtherServices(Service service, Function function)
        {
            if (service.Definition.VirtualPlatformServiceType == VirtualPlatformType.Reception)
            {
                /* Changing the source resource while Uutisalue destinations are present in the order
				 * might require a change of the destination resource because of the fixed tie line logic. */

                var uutisalueDestinationsForSameSource = liveVideoOrder.Destinations.Where(d => liveVideoOrder.ServicesArePartOfSameChain(service, d.Service) && d.Service.Definition.Id == ServiceDefinitionGuids.YleHelsinkiDestination && d.Service.Functions.Single().Parameters.Single(p => p.Id == ProfileParameterGuids.YleHelsinkiDestinationLocation).StringValue == "Uutisalue").ToList();

                Log(nameof(SetResourcesOnOtherServices), $"Found Uutisalue destinations {string.Join(", ", uutisalueDestinationsForSameSource.Select(d => d.Service.Name))}");

                foreach (var destination in uutisalueDestinationsForSameSource)
                {
                    destination.Service.AssignResourcesToFunctions(helpers, order);
                }
            }

            if (function.Resource == null)
            {
                liveVideoOrder.ClearMatchingResourceOnNeighborServiceConnectedFunction(service, function);
            }
            else if (service.Definition.VirtualPlatform == VirtualPlatform.Routing)
            {
                var routingServiceChainsWhereServiceIsPartOfTieLine = liveVideoOrder.GetRoutingServiceChainsForService(service.Id).Where(rsc => rsc.UsesMultipleRoutingServices).ToList();
                foreach (var routingServiceChain in routingServiceChainsWhereServiceIsPartOfTieLine)
                {
                    // Set the correct tie line resource on the neighbor routing service 

                    routingServiceChain.SetMatchingResourceOnNeighborServiceConnectedFunction(service, function);
                }
            }
            else
            {
                /* Resource changes (excluding setting resource to None/null) on non-routing services
				 * will result in routing reprocessing in the Book Services logic in the background
				 * causing the routing services to have the correct resource.
				 * So no need to set routing resources based on non-routing resource changes here.*/
            }
        }

        private void ConditionalSetFixedTieLineOverrideProperty(Service service, Function function)
        {
            if (!order.IsBooked)
            {
                Log(nameof(ConditionalSetFixedTieLineOverrideProperty), $"Order is not booked yet, no need to override fixed tie line logic");
                return;
            }

            bool serviceIsDestinationYleHelsinkiUutisalue = service.Definition.Id == ServiceDefinitionGuids.YleHelsinkiDestination && service.Functions.Single().Parameters.Single(p => p.Id == ProfileParameterGuids.YleHelsinkiDestinationLocation).StringValue.Equals("uutisalue");
            bool serviceIsRoutingPartOfTieLine = service.Definition.VirtualPlatform == VirtualPlatform.Routing && liveVideoOrder.GetLiveVideoService(service).FunctionIsConnectedToNeighborRoutingService(function);

            if (!serviceIsDestinationYleHelsinkiUutisalue && !serviceIsRoutingPartOfTieLine) return;

            var routingServiceChains = liveVideoOrder.GetRoutingServiceChainsForService(service.Id);
            foreach (var routingServiceChain in routingServiceChains)
            {
                bool inputServiceRequiresSpecificTieLine = routingServiceChain.InputService.OutputResource != null && routingServiceChain.InputService.OutputResource.RequiresSpecificTieLine();
                bool chainUsesFixedTieLineResources = routingServiceChain.AllRoutingServiceResources.Any(r => r.GetResourcePropertyBooleanValue(ResourcePropertyNames.IsSpecificTieLine));

                if (inputServiceRequiresSpecificTieLine || chainUsesFixedTieLineResources)
                {
                    function.McrHasOverruledFixedTieLineLogic = true;
                    Log(nameof(HandleSelectedResourceUpdate), $"Set service {service.Name} function {function.Name} property {nameof(function.McrHasOverruledFixedTieLineLogic)} to true");
                }
            }
        }

        private void HandleAudioProcessingServiceChanges(Service audioProcessingService)
        {
            if (audioProcessingService?.Definition?.VirtualPlatform == VirtualPlatform.AudioProcessing)
            {
                liveVideoOrder.UpdateLinkedLiveVideoServicesWhenAudioProcessingChanges(audioProcessingService);
            }
        }

        private void Initialize()
        {
            LogMethodStart(nameof(Initialize), out var stopwatch);

            InitializeServiceDefinitions();
            InitializeSharedSources();
            InitializeCachedServices();
            InitializeDisplayedOrder();
            SubscribeToUi();
            InitializeServiceControllers();

            LogMethodCompleted(nameof(Initialize), stopwatch);
        }

        private void InitializeServiceDefinitions()
        {
            var allServiceDefinitions = helpers.ServiceDefinitionManager.GetServiceDefinitionsForLiveOrderForm();

            var serviceDefinitions = new Dictionary<VirtualPlatformType, IReadOnlyList<ServiceDefinition>>
            {
                { VirtualPlatformType.Reception, new List<ServiceDefinition>() },
                { VirtualPlatformType.Destination, new List<ServiceDefinition>() },
                { VirtualPlatformType.Recording, new List<ServiceDefinition>() },
                { VirtualPlatformType.Transmission, new List<ServiceDefinition>() }
            };

            var allowedServiceDefinitions = new Dictionary<VirtualPlatformType, IReadOnlyList<ServiceDefinition>>
            {
                { VirtualPlatformType.Reception, new List<ServiceDefinition>() },
                { VirtualPlatformType.Destination, new List<ServiceDefinition>() },
                { VirtualPlatformType.Recording, new List<ServiceDefinition>() },
                { VirtualPlatformType.Transmission, new List<ServiceDefinition>() }
            };

            var receptions = allServiceDefinitions.ReceptionServiceDefinitions.ToList();
            receptions.Add(ServiceDefinition.GenerateDummyReceptionServiceDefinition());
            receptions.Add(ServiceDefinition.GenerateDummyUnknownReceptionServiceDefinition());
            receptions.Add(ServiceDefinition.GenerateEurovisionReceptionServiceDefinition());
            serviceDefinitions[VirtualPlatformType.Reception] = receptions;
            allowedServiceDefinitions[VirtualPlatformType.Reception] = receptions.Where(x => userInfo.Contract.IsServiceAllowed(x, userInfo)).ToList();

            serviceDefinitions[VirtualPlatformType.Destination] = allServiceDefinitions.DestinationServiceDefinitions.ToList();
            allowedServiceDefinitions[VirtualPlatformType.Destination] = allServiceDefinitions.DestinationServiceDefinitions.Where(x => userInfo.Contract.IsServiceAllowed(x, userInfo)).ToList();

            serviceDefinitions[VirtualPlatformType.Recording] = allServiceDefinitions.RecordingServiceDefinitions.ToList();
            allowedServiceDefinitions[VirtualPlatformType.Recording] = allServiceDefinitions.RecordingServiceDefinitions.Where(x => userInfo.Contract.IsServiceAllowed(x, userInfo)).ToList();

            var transmissions = allServiceDefinitions.TransmissionServiceDefinitions.ToList();
            transmissions.Add(ServiceDefinition.GenerateEurovisionTransmissionServiceDefinition());
            serviceDefinitions[VirtualPlatformType.Transmission] = transmissions;
            allowedServiceDefinitions[VirtualPlatformType.Transmission] = transmissions.Where(x => userInfo.Contract.IsServiceAllowed(x, userInfo)).ToList();

            this.serviceDefinitions = serviceDefinitions;
            this.allowedServiceDefinitions = allowedServiceDefinitions;
        }

        private void InitializeSharedSources()
        {
            var availableSharedSources = new List<SharedSourceInfo>();

            if (userInfo.AllUserContracts.Any(x => x != null && x.ContractGlobalEventLevelReceptionConfiguration.HasFlag(GlobalEventLevelReceptionConfigurations.GlobalEventLevelReceptionUsageAllowed)))
            {
                // Filter out shared sources that end in the past
                availableSharedSources = helpers.ServiceManager.GetSharedSourceReservationsEndingInFuture().Select(r => new SharedSourceInfo(helpers, r)).ToList();
            }

            sharedSources = availableSharedSources;
        }

        protected override void GenerateNewChildService(Service previousDisplayedService, string virtualPlatformName, string description, out DisplayedService newDisplayedService, out ServiceDefinition newServiceDefinition)
        {
            newServiceDefinition = serviceDefinitions[previousDisplayedService.Definition.VirtualPlatformServiceType].First(x => x.VirtualPlatformServiceName.GetDescription() == virtualPlatformName && x.Description == description);
            newDisplayedService = new DisplayedService(helpers, newServiceDefinition)
            {
                Start = order.Start,
                End = order.End,
                BackupType = previousDisplayedService.BackupType,
                AvailableServicesToRecordOrTransmit = order.AllServices.Where(x => x.BackupType == previousDisplayedService.BackupType && (x.Definition.VirtualPlatformServiceType == VirtualPlatformType.Reception || x.Definition.VirtualPlatformServiceType == VirtualPlatformType.Destination)).ToList(),
                NameOfServiceToTransmitOrRecord = (previousDisplayedService.BackupType == BackupType.None) ? order.SourceService.Name : order.BackupSourceService?.Name
            };

            if (newDisplayedService.Definition.VirtualPlatform == VirtualPlatform.Recording)
            {
                newDisplayedService.RecordingConfiguration.IsConfigured = true;
                newDisplayedService.RecordingConfiguration.RecordingName = order.Name;
                newDisplayedService.RecordingConfiguration.SelectableRecordingFileDestinations = newDisplayedService.Definition.Description.Contains("Live") ? new List<string> { FileDestination.ArchiveMetro.GetDescription() } : new List<string> { FileDestination.UaIplay.GetDescription() };
                newDisplayedService.RecordingConfiguration.RecordingFileDestination = newDisplayedService.Definition.Description.Contains("Live") ? FileDestination.ArchiveMetro : FileDestination.UaIplay;
            }

            newDisplayedService.RecordingConfiguration.RecordingName = order.Name;
            newDisplayedService.DisplayName = previousDisplayedService.DisplayName;

            if (newDisplayedService.BackupType == BackupType.None)
            {
                newDisplayedService.AudioChannelConfiguration?.CopyFromSource(order.SourceService.AudioChannelConfiguration);
                newDisplayedService.AudioChannelConfiguration?.SetSourceOptions(order.SourceService.AudioChannelConfiguration.GetSourceOptions());

                SetValuesBasedOnSourceService(newDisplayedService, order.SourceService);
            }
            else if (order.BackupSourceService != null)
            {
                newDisplayedService.AudioChannelConfiguration?.CopyFromSource(order.BackupSourceService.AudioChannelConfiguration);
                newDisplayedService.AudioChannelConfiguration?.SetSourceOptions(order.BackupSourceService.AudioChannelConfiguration.GetSourceOptions());

                SetValuesBasedOnSourceService(newDisplayedService, order.BackupSourceService);
            }
            else
            {
                // Nothing to do
            }
        }

        protected override void InitializeCachedServices()
        {
            base.InitializeCachedServices(); // cache main services

            if (order.BackupSourceService is null) return;

            InitializeCachedReceptionService(order.BackupSourceService);

            foreach (var service in OrderManager.FlattenServices(order.BackupSourceService.Children))
            {
                switch (service.Definition.VirtualPlatformServiceType)
                {
                    case VirtualPlatformType.Recording:
                    case VirtualPlatformType.Destination:
                    case VirtualPlatformType.Transmission:
                        cachedBackupSourceChildServices[service.Definition.VirtualPlatformServiceType].Add(new List<DisplayedService> { service as DisplayedService });
                        break;

                    default:
                        break;
                }
            }
        }

        protected override void SubscribeToUi()
        {
            base.SubscribeToUi();

            if (orderSection == null) return;

            orderSection.UseSharedSourceChanged += (s, e) => SharedSourceChanged();
       
            orderSection.SharedSourceChanged += (s, e) => SharedSourceChanged();

            orderSection.AddDestination += (s, e) => Section_AddChildService(VirtualPlatformType.Destination);
            orderSection.AddRecording += (s, e) => Section_AddChildService(VirtualPlatformType.Recording);
            orderSection.AddTransmission += (s, e) => Section_AddChildService(VirtualPlatformType.Transmission);

            orderSection.BackupSourceChanged += Section_BackupSourceChanged;
            orderSection.BackupSourceDescriptionChanged += Section_BackupSourceDescriptionChanged;
            orderSection.BackupSourceServiceLevelChanged += Section_BackupSourceServiceLevelChanged;
            orderSection.BackupSourceServiceSectionAdded += (s, addedBackupSourceServiceSection) => RegisterServiceController(addedBackupSourceServiceSection);

            orderSection.AdditionalInformationSection.DisplayedPropertyChanged += (s, e) => order.SetPropertyValue(helpers, e.PropertyName, e.PropertyValue);

            orderSection.SportsPlanningSection.DisplayedPropertyChanged += (s, e) => order.SportsPlanning.SetPropertyValue(helpers, e.PropertyName, e.PropertyValue);
            orderSection.SportsPlanningSection.CompetitionTimeChanged += (s, e) => order.SportsPlanning.CompetitionTime = Math.Round((e - new DateTime(1970, 1, 1)).TotalMilliseconds);
            orderSection.SportsPlanningSection.RequestedBroadcastTimeChanged += (s, e) => order.SportsPlanning.RequestedBroadcastTime = Math.Round((e - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Local)).TotalMilliseconds);

            orderSection.NewsInformationSection.DisplayedPropertyChanged += (s, e) => order.NewsInformation.SetPropertyValue(helpers, e.PropertyName, e.PropertyValue);
        }

        protected override void InitializeServiceControllers()
        {
            if (orderSection is null) return;

            base.InitializeServiceControllers();

            if (orderSection.BackupSourceServiceSection != null) RegisterServiceController(orderSection.BackupSourceServiceSection);
            foreach (var backupChildSection in orderSection.BackupSourceChildSections)
            {
                RegisterServiceSelectionSection(backupChildSection);
                foreach (var linkedRecordingServiceSection in backupChildSection.ChildSections) RegisterServiceSelectionSection(linkedRecordingServiceSection);
            }
        }

        protected override void InitializeDisplayedOrder()
        {
            base.InitializeDisplayedOrder();

            UpdateSharedSources(initialize: true);

            foreach (var service in order.AllServices)
            {
                UpdateAvailableServicesToRecordOrTransmit(service, false);
                if (service.Definition.VirtualPlatformServiceType != VirtualPlatformType.Reception)
                {
                    service.AudioChannelConfiguration.InitializeUiValues(service.BackupType == BackupType.None ? order.SourceService.AudioChannelConfiguration : order.BackupSourceService?.AudioChannelConfiguration, helpers);
                }
            }
        }

        private void SharedSourceChanged()
        {
            if (!orderSection.UseSharedSource)
            {
                if (order.SourceService.IsSharedSource)
                {
                    // When the Use Shared Source checkbox gets unselected and a shared source was selected -> set source service back to previously selected service
                    UpdateOrderSourceService(orderSection.Source, orderSection.SourceDescription);
                }
                else
                {
                    // When the Use Shared Source checkbox gets unselected and NO shared source was selected -> previous source is still in the order
                }

                return;
            }

            Log(nameof(SharedSourceChanged), $"Shared Source service changed to {orderSection.SharedSource}");

            var selectedSharedSource = sharedSources.FirstOrDefault(ss => ss.DropdownOption == orderSection.SharedSource);
            
            if (selectedSharedSource == null)
            {
                // If no shared sources are available
                helpers.Log(nameof(OrderController), nameof(SharedSourceChanged), $"No shared source found with short description: {orderSection.SharedSource}");
                return;
            }

            if (!cachedSharedSourceServices.TryGetValue(selectedSharedSource.SharedSourceReservation.ID, out DisplayedService sharedSourceService))
            {
                sharedSourceService = selectedSharedSource.GetSharedSourceService();

                // TODO: should change tracking be started for shared sources that were created in other orders?
                sharedSourceService.AcceptChanges();

                cachedSharedSourceServices.Add(sharedSourceService.Id, sharedSourceService);
            }

            Log(nameof(SharedSourceChanged), $"Updating Source Service to Shared Source {sharedSourceService.Name}");

            order.SourceService = sharedSourceService;
            AudioChannelConfigurationChanged(sharedSourceService);

            UpdateLiveVideoOrder();
            InvokeValidationRequired();
        }

        /// <summary>
        /// Called when the audio channel configuration that can apply to other services is updated.
        /// Whenever Copy From Source or a value of an Audio Channel Pair is updated.
        /// </summary>
        /// <param name="service">Service on which the change was performed.</param>
        private void AudioChannelConfigurationChanged(DisplayedService service)
        {
            // Update available Audio options when source service changes
            if (order.SourceService.Equals(service) || (order.BackupSourceService != null && order.BackupSourceService.Equals(service)))
            {
                var sourceOptions = service.AudioChannelConfiguration.GetSourceOptions();
                foreach (var childService in OrderManager.FlattenServices(service.Children))
                {
                    childService.AudioChannelConfiguration.SetSourceOptions(sourceOptions);
                }
            }
            else
            {
                if (service.BackupType == BackupType.None)
                {
                    if (service.AudioChannelConfiguration.IsCopyFromSource)
                    {
                        service.AudioChannelConfiguration.CopyFromSource(order.SourceService.AudioChannelConfiguration);
                        service.AudioChannelConfiguration.SetSourceOptions(order.SourceService.AudioChannelConfiguration.GetSourceOptions());
                    }
                    else if (!service.AudioChannelConfiguration.MatchesSourceConfiguration(order.SourceService.AudioChannelConfiguration) && service.AudioChannelConfiguration.AudioShufflingRequiredProfileParameter != null)
                    {
                        service.AudioChannelConfiguration.AudioShufflingRequiredProfileParameter.Value = "Yes";
                    }
                }
                else
                {
                    if (service.AudioChannelConfiguration.IsCopyFromSource)
                    {
                        service.AudioChannelConfiguration.CopyFromSource(order.BackupSourceService.AudioChannelConfiguration);
                        service.AudioChannelConfiguration.SetSourceOptions(order.BackupSourceService.AudioChannelConfiguration.GetSourceOptions());
                    }
                    else if (!service.AudioChannelConfiguration.MatchesSourceConfiguration(order.BackupSourceService.AudioChannelConfiguration) && service.AudioChannelConfiguration.AudioShufflingRequiredProfileParameter != null)
                    {
                        service.AudioChannelConfiguration.AudioShufflingRequiredProfileParameter.Value = "Yes";
                    }
                }
            }

            // Get affected services and copy Audio Channel configuration
            var linkedServices = GetLinkedAudioProcessingServices(service);

            foreach (var linkedAudioConfiguration in linkedServices.Select(x => x.AudioChannelConfiguration))
            {
                linkedAudioConfiguration.CopyFromSource(service.AudioChannelConfiguration);
                linkedAudioConfiguration.UpdateSelectableOptions();
            }

            Section.RegenerateUI();
        }

        private IEnumerable<DisplayedService> GetLinkedAudioProcessingServices(DisplayedService sourceService)
        {
            List<DisplayedService> linkedProcessingServices = new List<DisplayedService>();
            foreach (var service in order.AllServices.Cast<DisplayedService>())
            {
                if (sourceService.Equals(service)) continue;
                if (service.BackupType != sourceService.BackupType) continue;

                switch (service.Definition.VirtualPlatformServiceType)
                {
                    case VirtualPlatformType.Destination:
                        if (sourceService.Definition.VirtualPlatformServiceType == VirtualPlatformType.Reception && service.AudioChannelConfiguration.IsCopyFromSource)
                        {
                            linkedProcessingServices.Add(service);
                            linkedProcessingServices.AddRange(GetLinkedAudioProcessingServices(service));
                        }
                        break;
                    case VirtualPlatformType.Recording:
                    case VirtualPlatformType.Transmission:
                        if (String.Equals(sourceService.Name, service.NameOfServiceToTransmitOrRecord) && service.AudioChannelConfiguration.IsCopyFromSource) linkedProcessingServices.Add(service);
                        break;
                    default:
                        // Don't update service
                        break;
                }
            }

            return linkedProcessingServices;
        }


        private void Section_BackupSourceChanged(object sender, string e)
        {
            var backupSourceServiceDefinitions = allowedServiceDefinitions[VirtualPlatformType.Reception].Where(x => x.VirtualPlatformServiceName.GetDescription() == e).ToList();
            order.AvailableBackupSourceServiceDescriptions = backupSourceServiceDefinitions.Select(s => s.Description).OrderBy(s => s).ToList();

            var defaultServiceDefinition = backupSourceServiceDefinitions.FirstOrDefault(x => x.IsDefault) ?? backupSourceServiceDefinitions.First();

            UpdateOrderBackupSourceService(orderSection.BackupSource, defaultServiceDefinition.Description);
        }

        private void Section_BackupSourceDescriptionChanged(object sender, string e)
        {
            helpers.Log(nameof(OrderController), nameof(Section_BackupSourceDescriptionChanged), $"Backup Source Description Dropdown changed: {e}");

            UpdateOrderBackupSourceService(orderSection.BackupSource, e);
        }

        private void Section_BackupSourceServiceLevelChanged(object sender, BackupType backupType)
        {
            helpers.Log(nameof(OrderController), nameof(Section_BackupSourceServiceLevelChanged), $"Backup Source Service Level Dropdown changed: {backupType.GetDescription()}");

            if (backupType == order.BackupSourceService.BackupType) return;

            BackupType previousBackupType = order.BackupSourceService.BackupType;
            order.BackupSourceService.BackupType = backupType;

            bool activeToColdOrStandby = previousBackupType == BackupType.Active;
            bool coldOrStandbyToActive = backupType == BackupType.Active;

            if (activeToColdOrStandby)
            {
                // Remove all backup children
                foreach (var backupChildService in order.BackupSourceService.NonAutoGeneratedChildren) RemoveBackupChildService(backupChildService);
                order.BackupSourceService.Children.Clear();
            }
            else if (coldOrStandbyToActive)
            {
                foreach (var child in order.SourceService.NonAutoGeneratedChildren)
                {
                    Section_AddBackupChildService(child);
                }
            }
            else
            {
                // Cold <-> Standby
                // Nothing to do
            }

            foreach (var service in order.AllServices) UpdateAvailableServicesToRecordOrTransmit(service, false);

            UpdateLiveVideoOrder();
        }

        protected override void ReplaceService(Service existingService, DisplayedService newService)
        {
            base.ReplaceService(existingService, newService);

            UpdateServicesToRecordOrTransmit(existingService, newService);
            AudioChannelConfigurationChanged(newService);

            InvokeValidationRequired();
        }

        /// <summary>
        /// Updates the service to Record Or Transmit property on recording and transmission services in the order when a service gets switched.
        /// if newly displayed service is null, the property will be set to the source service.
        /// </summary>
        /// <param name="previousService">Previously displayed service.</param>
        /// <param name="newService">Newly displayed service, can be null.</param>
        private void UpdateServicesToRecordOrTransmit(Service previousService, Service newService)
        {
            if (previousService == null) return; // Can be null for example when switching Backup Source type from None

            Log(nameof(UpdateServicesToRecordOrTransmit), $"Previous Service {previousService.Name}, replaced with {newService?.Name}");

            foreach (var service in order.AllServices)
            {
                if (service.Definition.VirtualPlatformServiceType != VirtualPlatformType.Recording && service.Definition.VirtualPlatformServiceType != VirtualPlatformType.Transmission) continue;

                if (service.NameOfServiceToTransmitOrRecord != previousService.Name) continue;

                if (newService != null)
                {
                    service.NameOfServiceToTransmitOrRecord = newService.Name;
                }
                else if (service.BackupType == BackupType.None)
                {
                    service.NameOfServiceToTransmitOrRecord = order.SourceService.Name;
                }
                else
                {
                    service.NameOfServiceToTransmitOrRecord = order.BackupSourceService?.Name;
                }
            }
        }

        public override void AddChildService(DisplayedService serviceToAdd)
        {
            base.AddChildService(serviceToAdd);

            foreach (var otherService in order.AllServices) UpdateAvailableServicesToRecordOrTransmit(otherService, false);

            if (order.BackupSourceService?.BackupType == BackupType.Active)
            {
                Section_AddBackupChildService(serviceToAdd);
            }

            UpdateLiveVideoOrder();
        }

        protected override void InitializeServiceBeforeBeingAdded(DisplayedService serviceToAdd, Service replacedService = null)
        {
            base.InitializeServiceBeforeBeingAdded(serviceToAdd, replacedService);

            CopyProcessingSettings(serviceToAdd, order.SourceService);

            UpdateAvailableServicesToRecordOrTransmit(serviceToAdd, true);

            if (serviceToAdd.Definition.VirtualPlatform == VirtualPlatform.Recording)
            {
                serviceToAdd.RecordingConfiguration.IsConfigured = true;
                serviceToAdd.RecordingConfiguration.RecordingName = order.Name;
                serviceToAdd.RecordingConfiguration.SelectableRecordingFileDestinations = serviceToAdd.Definition.Description.Contains("Live") ? new List<string> { FileDestination.ArchiveMetro.GetDescription() } : new List<string> { FileDestination.UaIplay.GetDescription() };
                serviceToAdd.RecordingConfiguration.RecordingFileDestination = serviceToAdd.Definition.Description.Contains("Live") ? FileDestination.ArchiveMetro : FileDestination.UaIplay;
            }

            serviceToAdd.AcceptChanges();
        }

        protected override void DeleteEndpointService(Service sectionService)
        {
            base.DeleteEndpointService(sectionService);

            if (order.BackupSourceService?.BackupType == BackupType.Active)
            {
                RemoveBackupChildServiceByLinkedService(sectionService);
            }

            UpdateServicesToRecordOrTransmit(sectionService, null);

            foreach (var service in order.AllServices) UpdateAvailableServicesToRecordOrTransmit(service, false);

            UpdateLiveVideoOrder();
        }

        private void UpdateAvailableServicesToRecordOrTransmit(Service service, bool initServiceToRecordOrTransmit)
        {
            if (service.Definition.VirtualPlatformServiceType != VirtualPlatformType.Recording && service.Definition.VirtualPlatformServiceType != VirtualPlatformType.Transmission) return;

            var availableServicesToRecordOrTransmit = order.AllServices.Where(x => x.BackupType == service.BackupType && (x.Definition.VirtualPlatformServiceType == VirtualPlatformType.Reception || x.Definition.VirtualPlatformServiceType == VirtualPlatformType.Destination)).ToList();

            service.AvailableServicesToRecordOrTransmit = availableServicesToRecordOrTransmit;

            if (!initServiceToRecordOrTransmit) return;

            service.NameOfServiceToTransmitOrRecord = (service.BackupType == BackupType.None) ? order.SourceService.Name : order.BackupSourceService?.Name;
        }

        private void UpdateOrderBackupSourceService(string backupSource, string backupSourceDescription)
        {
            helpers.Log(nameof(OrderController), nameof(UpdateOrderBackupSourceService), $"Updating Source Service to '{backupSource}' - '{backupSourceDescription}'");

            var serviceDefinition = allowedServiceDefinitions[VirtualPlatformType.Reception].First(x => x.VirtualPlatformServiceName.GetDescription() == backupSource && x.Description == backupSourceDescription);

            if (serviceDefinition.VirtualPlatform == VirtualPlatform.ReceptionNone)
            {
                // Remove Backup Service from order
                UpdateServicesToRecordOrTransmit(order.BackupSourceService, null);
                order.BackupSourceService = null;
            }
            else
            {
                if (!cachedBackupReceptionServices.TryGetValue(serviceDefinition.Name, out var service))
                {
                    service = new DisplayedService(helpers, serviceDefinition)
                    {
                        Start = order.Start,
                        End = order.End,
                    };

                    if (order.IntegrationType != IntegrationType.None)
                    {
                        service.PreRoll = ServiceManager.GetPreRollDuration(serviceDefinition, order.IntegrationType);
                        service.PostRoll = ServiceManager.GetPostRollDuration(serviceDefinition, order.IntegrationType);
                    }

                    service.AcceptChanges();
                    cachedBackupReceptionServices.Add(serviceDefinition.Name, service);
                }

                service.BackupType = orderSection.BackupSourceServiceLevel;

                helpers.Log(nameof(OrderController), nameof(UpdateOrderBackupSourceService), $"Updating Backup Source Service to {service.Name}, {service.Definition.VirtualPlatform} ({service.Definition.Description}, backupType {service.BackupType.GetDescription()})");

                UpdateServicesToRecordOrTransmit(order.BackupSourceService, service);
                order.BackupSourceService = service;
            }

            UpdateLiveVideoOrder();

            InvokeValidationRequired();
        }

        private void Section_AddBackupChildService(Service linkedService)
        {
            var backupChildService = new DisplayedService(helpers, linkedService.Definition)
            {
                Start = linkedService.Start,
                End = linkedService.End,
                BackupType = BackupType.Active,
                LinkedService = linkedService,
            };

            if (backupChildService.Definition.VirtualPlatform == VirtualPlatform.Recording)
            {
                backupChildService.RecordingConfiguration.IsConfigured = true;
                backupChildService.RecordingConfiguration.RecordingName = order.Name;
                backupChildService.RecordingConfiguration.SelectableRecordingFileDestinations = backupChildService.Definition.Description.Contains("Live") ? new List<string> { FileDestination.ArchiveMetro.GetDescription() } : new List<string> { FileDestination.UaIplay.GetDescription() };
                backupChildService.RecordingConfiguration.RecordingFileDestination = backupChildService.Definition.Description.Contains("Live") ? FileDestination.ArchiveMetro : FileDestination.UaIplay;
            }

            for (int i = 1; i <= order.AllBackupServices.Count(s => s.Definition.VirtualPlatformServiceType == backupChildService.Definition.VirtualPlatformServiceType) + 1; i++)
            {
                string potentialDisplayName = $"Backup {backupChildService.Definition.VirtualPlatformServiceType.GetDescription()} {i}";

                if (!order.AllBackupServices.Any(s => s.DisplayName == potentialDisplayName))
                {
                    backupChildService.DisplayName = potentialDisplayName;
                }
            }

            if (order.IntegrationType != IntegrationType.None)
            {
                backupChildService.PreRoll = ServiceManager.GetPostRollDuration(backupChildService.Definition, order.IntegrationType);
                backupChildService.PostRoll = ServiceManager.GetPostRollDuration(backupChildService.Definition, order.IntegrationType);
            }

            CopyProcessingSettings(backupChildService, order.BackupSourceService);

            backupChildService.SetAvailableVirtualPlatformNames(allowedServiceDefinitions[backupChildService.Definition.VirtualPlatformServiceType].Select(x => x.VirtualPlatformServiceName.GetDescription()));
            backupChildService.SetAvailableServiceDescriptions(allowedServiceDefinitions[backupChildService.Definition.VirtualPlatformServiceType].Where(x => x.VirtualPlatform == backupChildService.Definition.VirtualPlatform).Select(x => x.Description));

            UpdateAvailableServicesToRecordOrTransmit(backupChildService, true);

            Log(nameof(Section_AddBackupChildService), $"Name of Service To Record Or Transmit: {backupChildService.NameOfServiceToTransmitOrRecord}");

            backupChildService.AcceptChanges();

            cachedBackupSourceChildServices[backupChildService.Definition.VirtualPlatformServiceType].Add(new List<DisplayedService> { backupChildService });

            order.BackupSourceService.Children.Add(backupChildService);

            InvokeValidationRequired();
        }

        private void CopyProcessingSettings(Service serviceToUpdate, Service sourceService)
        {
            CopyVideoFormat(serviceToUpdate, sourceService);

            serviceToUpdate.AudioChannelConfiguration.CopyFromSource(sourceService.AudioChannelConfiguration);
            Log(nameof(CopyProcessingSettings), $"Audio Config of {serviceToUpdate.Name} after copy, {serviceToUpdate.AudioChannelConfiguration}");

            serviceToUpdate.AudioChannelConfiguration.SetSourceOptions(sourceService.AudioChannelConfiguration.GetSourceOptions());
            Log(nameof(CopyProcessingSettings), $"Audio Config of {serviceToUpdate.Name} after updating options, {serviceToUpdate.AudioChannelConfiguration}");

            if (serviceToUpdate.Definition.Description.Equals("messi news", StringComparison.OrdinalIgnoreCase) && serviceToUpdate.IntegrationType == IntegrationType.None)
            {
                // Recording Messi News connected to a IP RX Vidigo source does not require routing

                bool sourceIsIpVidigoReception = sourceService.Definition.VirtualPlatform == VirtualPlatform.ReceptionIp && sourceService.Definition.Description == "Vidigo";

                serviceToUpdate.RequiresRouting = !sourceIsIpVidigoReception;

                Log(nameof(CopyProcessingSettings), $"Service {serviceToUpdate.Name} is a manual Messi News recording service, RequiresRouting property set to {serviceToUpdate.RequiresRouting}, based on if the source is IP Vidigo");
            }
        }

        private void CopyVideoFormat(Service serviceToUpdate, Service sourceService)
        {
            var sourceVideoFormatProfileParameter = sourceService.Functions.SelectMany(f => f.Parameters).FirstOrDefault(pp => pp.Id == ProfileParameterGuids.VideoFormat);
            var childVideoFormatProfileParameter = serviceToUpdate.Functions.SelectMany(f => f.Parameters).FirstOrDefault(pp => pp.Id == ProfileParameterGuids.VideoFormat);

            if (sourceVideoFormatProfileParameter is null)
            {
                Log(nameof(CopyVideoFormat), $"WARNING: Could not find Video Format profile parameter in source service {sourceService.Name} to copy its value to service {serviceToUpdate.Name}");
            }
            else if (childVideoFormatProfileParameter is null)
            {
                Log(nameof(CopyVideoFormat), $"WARNING: Could not find Video Format profile parameter in service {serviceToUpdate.Name} to copy its value from source service {sourceService.Name}");
            }
            else
            {
                childVideoFormatProfileParameter.Value = sourceVideoFormatProfileParameter.Value;
                Log(nameof(CopyVideoFormat), $"Copied source service {sourceService} profile parameter {sourceVideoFormatProfileParameter.Name} value {sourceVideoFormatProfileParameter.StringValue} to service {serviceToUpdate.Name}");
            }
        }

        private void RemoveBackupChildServiceByLinkedService(Service linkedService)
        {
            var backupService = order.AllServices.FirstOrDefault(x => x.LinkedService != null && x.LinkedService.Equals(linkedService));
            if (backupService == null) return;

            RemoveBackupChildService(backupService);
            UpdateServicesToRecordOrTransmit(backupService, null);
        }

        private void RemoveBackupChildService(Service backupService)
        {
            var cachedAlternativeServices = cachedBackupSourceChildServices[backupService.Definition.VirtualPlatformServiceType].First(x => x.Contains(backupService));
            Log(nameof(RemoveBackupChildService), $"Removing cached backup source services: {String.Join(", ", cachedAlternativeServices.Select(x => (x.Name + " " + x.Definition.Name)))}");

            cachedBackupSourceChildServices[backupService.Definition.VirtualPlatformServiceType].Remove(cachedAlternativeServices);

            var parentService = order.AllServices.FirstOrDefault(x => x.Children.Contains(backupService));
            parentService.Children.Remove(backupService);

            foreach (var serviceToRemove in cachedAlternativeServices)
            {
                serviceControllers.Remove(serviceToRemove);
            }
        }

        protected override void RegisterServiceController(ServiceSection e)
        {
            base.RegisterServiceController(e);

            serviceControllers[e.Service].BookEurovisionService += (sender, args) => OnBookEurovisionService(e.Service);
            serviceControllers[e.Service].AudioChannelConfigurationChanged += (sender, args) => AudioChannelConfigurationChanged(e.Service);
            serviceControllers[e.Service].ServiceToRecordOrTransmitChanged += (sender, args) => ServiceToRecordOrTransmitChanged(e.Service, args);
            serviceControllers[e.Service].UploadJsonButtonPressed += (sender, args) => OnUploadJsonButtonPressed();
            serviceControllers[e.Service].UploadSynopsisButtonPressed += (sender, args) => OnUploadSynopsisButtonPressed(e.Service);
            serviceControllers[e.Service].OrderValidationRequired += (sender, args) => InvokeValidationRequired();
        }

        protected override void OrderStartTimeChanged(DateTime orderStartTime)
        {
            LogMethodStart(nameof(OrderStartTimeChanged), out var stopwatch);

            base.OrderStartTimeChanged(orderStartTime);

            UpdateSharedSources();

            LogMethodCompleted(nameof(OrderStartTimeChanged), stopwatch);
        }

        protected override void OrderEndTimeChanged(DateTime orderEndTime)
        {
            LogMethodStart(nameof(OrderEndTimeChanged), out var stopwatch);

            base.OrderEndTimeChanged(orderEndTime);

            UpdateSharedSources();

            LogMethodCompleted(nameof(OrderEndTimeChanged), stopwatch);
        }

        private void ServiceToRecordOrTransmitChanged(DisplayedService service, string nameOfServiceToRecordOrTransmit)
        {
            if (order.SourceService.Name.Equals(nameOfServiceToRecordOrTransmit))
            {
                helpers.Log(nameof(OrderController), nameof(ServiceToRecordOrTransmitChanged), $"{service.Name} records or transmits the source service");
                if (service.AudioChannelConfiguration.IsCopyFromSource) service.AudioChannelConfiguration.CopyFromSource(order.SourceService.AudioChannelConfiguration);
            }
            else if (order.BackupSourceService != null && order.BackupSourceService.Name.Equals(nameOfServiceToRecordOrTransmit))
            {
                helpers.Log(nameof(OrderController), nameof(ServiceToRecordOrTransmitChanged), $"{service.Name} records or transmits the backup source service");
                if (service.AudioChannelConfiguration.IsCopyFromSource) service.AudioChannelConfiguration.CopyFromSource(order.BackupSourceService.AudioChannelConfiguration);
            }
            else
            {
                helpers.Log(nameof(OrderController), nameof(ServiceToRecordOrTransmitChanged), $"{service.Name} records or transmits another service");

                // Copy audio config and video config and disable them
                Service serviceToRecordOrTransmit = order.AllServices.First(x => x.Name.Equals(nameOfServiceToRecordOrTransmit));
                service.AudioChannelConfiguration.CopyFromSource(serviceToRecordOrTransmit.AudioChannelConfiguration);
                service.AudioChannelConfiguration.SetSourceOptions(serviceToRecordOrTransmit.AudioChannelConfiguration.GetSourceOptions());
            }
        }

        public override void HandleServiceTimeUpdate()
        {
            base.HandleServiceTimeUpdate();

            UpdateSharedSources();
        }

        private void UpdateSharedSources(bool initialize = false)
        {
            LogMethodStart(nameof(UpdateSharedSources), out var stopwatch);

            var selectableSharedSources = sharedSources.Where(s => s.SharedSourceStartWithPreRoll <= order.Start && order.End <= s.SharedSourceEndWithPostRoll).ToList();
            var unavailableSharedSources = sharedSources.Except(selectableSharedSources);

            bool availableSharedSourcesChanged = !order.AvailableSharedSources.ToHashSet().SetEquals(selectableSharedSources);
            if (!initialize && !availableSharedSourcesChanged)
			{
                Log(nameof(UpdateSharedSources), $"Available and unavailable shared sources did not change.");
                LogMethodCompleted(nameof(UpdateSharedSources), stopwatch);
                return;
            }

            order.SetAvailableSharedSources(selectableSharedSources);
            order.SetUnavailableSharedSources(unavailableSharedSources);

            Log(nameof(UpdateSharedSources), $"Available shared sources: '{string.Join(";", order.AvailableSharedSources.Select(x => $"{x.SharedSourceReservation.Name} (option '{x.DropdownOption}')"))}'");
            Log(nameof(UpdateSharedSources), $"Unavailable shared sources: '{string.Join(";", order.UnavailableSharedSources.Select(x => $"{x.SharedSourceReservation.Name} (option '{x.DropdownOption}')"))}'");

            var previousSelectedSharedSourceShortDescription = orderSection?.Source;

            if (initialize || orderSection is null)
            {
                LogMethodCompleted(nameof(UpdateSharedSources), stopwatch);
                return;
            }

            Log(nameof(UpdateSharedSources), $"Use Shared Source is{(orderSection.UseSharedSource ? string.Empty : " not")} checked. Previous selected shared source is '{previousSelectedSharedSourceShortDescription}'. Current selected shared source is '{orderSection.SharedSource}'.");

            if (selectableSharedSources.Any() && orderSection.UseSharedSource)
            {
                // Other shared sources available, update the order source service to the one that is auto-selected by the dropdown.
                SharedSourceChanged();
            }

            LogMethodCompleted(nameof(UpdateSharedSources), stopwatch);
        }

        protected override List<DisplayedService> GetCachedAlternativeServices(Service previousDisplayedService)
        {
            List<DisplayedService> cachedAlternativeServices;
            if (previousDisplayedService.BackupType == BackupType.None)
            {
                cachedAlternativeServices = cachedSourceChildServices[previousDisplayedService.Definition.VirtualPlatformServiceType].First(x => x.Contains(previousDisplayedService));
            }
            else
            {
                cachedAlternativeServices = cachedBackupSourceChildServices[previousDisplayedService.Definition.VirtualPlatformServiceType].First(x => x.Contains(previousDisplayedService));
            }

            return cachedAlternativeServices;
        }
    }
}
