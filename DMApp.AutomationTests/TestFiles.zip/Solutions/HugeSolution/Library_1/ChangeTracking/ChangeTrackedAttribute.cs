﻿namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.ChangeTracking
{
	using System;

	[AttributeUsage(AttributeTargets.Property)]
	public class ChangeTrackedAttribute : Attribute
	{

	}
}
