namespace HandleOrderAction_1
{
	public enum Action
	{
		BookServices,
		BookEventLevelReceptionServices,
		DeleteServices
	}
}