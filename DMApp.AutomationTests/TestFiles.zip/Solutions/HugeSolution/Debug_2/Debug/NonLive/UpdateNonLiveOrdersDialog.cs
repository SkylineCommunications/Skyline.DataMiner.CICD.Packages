﻿using System;
using System.Linq;
using Skyline.DataMiner.DeveloperCommunityLibrary.InteractiveAutomationToolkit;
using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.Debug;
using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;

namespace Debug_2.Debug.NonLive
{
	public class UpdateNonLiveOrdersDialog : DebugDialog
	{
		private readonly Label header = new Label("Update Non-Live Order") { Style = TextStyle.Heading };

		private readonly Button updateUserTasksAndPropertiesForCompletedNonLiveOrders = new Button("Update user tasks and properties for completed non-live orders");
		private readonly Label explanationLabel = new Label("Feature created for DCP195594");

		public UpdateNonLiveOrdersDialog(Helpers helpers) : base(helpers)
		{
			updateUserTasksAndPropertiesForCompletedNonLiveOrders.Pressed += UpdateUserTasksAndPropertiesForCompletedNonLiveOrders_Pressed;
			GenerateUi();
		}

		private void UpdateUserTasksAndPropertiesForCompletedNonLiveOrders_Pressed(object sender, EventArgs e)
		{
			helpers.NonLiveOrderManager.TryGetAllCompletedNonLiveOrders(out var completedNonLiveOrders);

			foreach (var nonLiveOrder in completedNonLiveOrders)
			{
				helpers.NonLiveUserTaskManager.AddOrUpdateUserTasks(nonLiveOrder);
			}

			ShowRequestResult($"Updated user tasks for {completedNonLiveOrders.Count()} completed non-live orders", string.Join("\n", completedNonLiveOrders.Select(u => $"{u.ShortDescription}")));
		}

		private void GenerateUi()
		{
			Clear();

			int row = -1;

			AddWidget(BackButton, ++row, 0);
			AddWidget(new WhiteSpace(), ++row, 0);

			AddWidget(header, ++row, 0);

			AddWidget(updateUserTasksAndPropertiesForCompletedNonLiveOrders, ++row, 0);
			AddWidget(explanationLabel, row, 1);

			base.AddResponseSections(row);
		}
	}
}
