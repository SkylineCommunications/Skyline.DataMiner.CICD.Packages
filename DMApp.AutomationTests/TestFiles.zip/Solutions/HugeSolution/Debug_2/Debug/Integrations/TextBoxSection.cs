﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Skyline.DataMiner.DeveloperCommunityLibrary.InteractiveAutomationToolkit;
using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;

namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.YleWidgets
{
	public class TextBoxSection : Section
	{
		private readonly Helpers helpers;

		private readonly Label nameLabel = new Label();
		private readonly TextBox valueTextBox = new TextBox();

		public TextBoxSection(Helpers helpers, string parameterName)
		{
			this.helpers = helpers;

			Initialize(parameterName);
			GenerateUi();
		}

		public string TextBoxValue
		{
			get => valueTextBox.Text;
			set => valueTextBox.Text = value;
		}

		private void Initialize(string parameterName)
		{
			nameLabel.Text = parameterName;
		}

		private void GenerateUi()
		{
			Clear();

			int row = -1;

			AddWidget(nameLabel, ++row, 0);
			AddWidget(valueTextBox, row, 1);
		}
	}
}
