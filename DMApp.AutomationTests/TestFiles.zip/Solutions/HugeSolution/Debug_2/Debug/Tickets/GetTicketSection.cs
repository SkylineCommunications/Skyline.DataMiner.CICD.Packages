﻿namespace Debug_2.Debug.NonLiveOrders
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using Library.UI.Filters;
	using Skyline.DataMiner.DeveloperCommunityLibrary.InteractiveAutomationToolkit;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;
	using Skyline.DataMiner.Net.GenericEnums;
	using Skyline.DataMiner.Net.Messages.SLDataGateway;
	using Skyline.DataMiner.Net.Ticketing;

	public class GetTicketSection : Section
	{
		private readonly Label header = new Label("Get Tickets with filters") { Style = TextStyle.Heading };

		private readonly FilterSection<Ticket> ticketIdFilterSection = new StringFilterSection<Ticket>("Ticket ID", x => TicketingExposers.FullID.Equal((String)x));

		private readonly FilterSection<Ticket> ticketIdCreationDateFromFilterSection = new DateTimeFilterSection<Ticket>("Creation Date From", x => TicketingExposers.CreationDate.GreaterThanOrEqual((DateTime)x));

		private readonly FilterSection<Ticket> ticketIdCreationDateUntilFilterSection = new DateTimeFilterSection<Ticket>("Creation Date Until", x => TicketingExposers.CreationDate.LessThanOrEqual((DateTime)x));

		private readonly List<FilterSection<Ticket>> propertyFilterSections = new List<FilterSection<Ticket>>();

		private readonly Button addPropertyFilterButton = new Button("Add Property Filter");

		private readonly Button getSelectedTicketsButton = new Button("Get Selected Tickets") { Style = ButtonStyle.CallToAction };
		private readonly CollapseButton showSelectedTicketsButton;
		private readonly TextBox selectedTicketsTextBox = new TextBox() { IsMultiline = true, MinWidth = 500 };
		
		private readonly TicketingGatewayHelper ticketingHelper;

		public GetTicketSection()
		{
			ticketingHelper = new TicketingGatewayHelper { HandleEventsAsync = false };
			ticketingHelper.RequestResponseEvent += (sender, args) => args.responseMessage = Skyline.DataMiner.Automation.Engine.SLNet.SendSingleResponseMessage(args.requestMessage);

			addPropertyFilterButton.Pressed += AddPropertyFilterButton_Pressed;

			showSelectedTicketsButton = new CollapseButton(selectedTicketsTextBox.Yield(), true) { CollapseText = "Hide Selected Tickets", ExpandText = "Show Selected Tickets" };

			getSelectedTicketsButton.Pressed += (s,e) => SelectedTickets = GetSelectedTickets();

			GenerateUi();
		}

		public event EventHandler RegenerateUi;

		public IEnumerable<Ticket> SelectedTickets { get; private set; } = new List<Ticket>();

		public void GenerateUi()
		{
			Clear();

			int row = -1;

			AddWidget(header, ++row, 0, 1, 5);

			AddSection(ticketIdFilterSection, new SectionLayout(++row, 0));

			AddSection(ticketIdCreationDateFromFilterSection, new SectionLayout(++row, 0));

			AddSection(ticketIdCreationDateUntilFilterSection, new SectionLayout(++row, 0));

			foreach (var propertyFilterSerction in propertyFilterSections)
			{
				AddSection(propertyFilterSerction, new SectionLayout(++row, 0));
			}

			AddWidget(addPropertyFilterButton, ++row, 0);

			AddWidget(new WhiteSpace(), ++row, 0);

			AddWidget(getSelectedTicketsButton, ++row, 0);
			AddWidget(showSelectedTicketsButton, row, 1);
			AddWidget(selectedTicketsTextBox, ++row, 1);
		}

		private void AddPropertyFilterButton_Pressed(object sender, EventArgs e)
		{
			var propertyFilterSection = new PropertyFilterSection<Ticket>("Property", (propertyName, propertyValue) => TicketingExposers.CustomTicketFields.DictStringField((string)propertyName).Equal((string)propertyValue));

			propertyFilterSections.Add(propertyFilterSection);

			RegenerateUi?.Invoke(this, EventArgs.Empty);
		}

		private IEnumerable<Ticket> GetSelectedTickets()
		{
			selectedTicketsTextBox.Text = String.Empty;
			if (!this.ActiveFiltersAreValid<Ticket>()) return new List<Ticket>();

			var selectedTickets = new HashSet<Ticket>(ticketingHelper.GetTickets(null, this.GetCombinedFilterElement<Ticket>(), false).ToList());			

			selectedTicketsTextBox.Text = String.Join("\n", selectedTickets.Select(r => r.ID).OrderBy(id => id));

			return selectedTickets;
		}
	}
}
