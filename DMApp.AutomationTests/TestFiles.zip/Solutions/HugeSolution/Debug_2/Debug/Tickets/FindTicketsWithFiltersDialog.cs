﻿namespace Debug_2.Debug.NonLiveOrders
{
	using System;
	using System.Linq;
	using Newtonsoft.Json;
	using Skyline.DataMiner.DeveloperCommunityLibrary.InteractiveAutomationToolkit;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.IngestExport;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.Debug;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;
	using Skyline.DataMiner.Net.GenericEnums;

	public class FindTicketsWithFiltersDialog : DebugDialog
	{
		private readonly GetTicketSection getTicketsSection;

		private readonly Button showJsonButton = new Button("Show Tickets JSON");

		public FindTicketsWithFiltersDialog(Helpers helpers) : base(helpers)
		{
			getTicketsSection = new GetTicketSection();

			Title = "Find Tickets with Filters";
			Initialize();
			GenerateUi();
		}

		private void Initialize()
		{
			getTicketsSection.RegenerateUi += GetTicketsSection_RegenerateUi;

			showJsonButton.Pressed += ShowJsonButton_Pressed;
		}

		private void GetTicketsSection_RegenerateUi(object sender, EventArgs e)
		{
			getTicketsSection.GenerateUi();
			GenerateUi();
		}

		private void ShowJsonButton_Pressed(object sender, EventArgs e)
		{
			ShowRequestResult("Serialized Tickets", string.Join("\n", getTicketsSection.SelectedTickets.Select(r => JsonConvert.SerializeObject(r))));
			getTicketsSection.GenerateUi();
			GenerateUi();
		}

		private void GenerateUi()
		{
			Clear();

			int row = -1;

			AddWidget(BackButton, ++row, 0, 1, 3);

			AddSection(getTicketsSection, new SectionLayout(++row, 0));
			row += getTicketsSection.RowCount;

			AddWidget(new WhiteSpace(), ++row, 0);
			AddWidget(showJsonButton, ++row, 0);

			AddWidget(new WhiteSpace(), ++row, 0);

			AddResponseSections(row);
		}
	}
}
