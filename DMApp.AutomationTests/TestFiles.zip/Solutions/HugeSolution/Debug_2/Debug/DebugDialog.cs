﻿namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.Debug
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using Skyline.DataMiner.Automation;
	using Skyline.DataMiner.DeveloperCommunityLibrary.InteractiveAutomationToolkit;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.DataMinerInterface;
	using Skyline.DataMiner.Library.Solutions.SRM;
	using Skyline.DataMiner.Net.Messages.SLDataGateway;
	using Skyline.DataMiner.Net.ResourceManager.Objects;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.Debug;

	public abstract class DebugDialog : Dialog
	{
		protected readonly Helpers helpers;

		protected readonly List<RequestResultSection> responseSections = new List<RequestResultSection>();

		protected DebugDialog(Helpers helpers) : base(helpers.Engine)
		{
			this.helpers = helpers ?? throw new ArgumentNullException(nameof(helpers));
		}

		public Button BackButton { get; } = new Button("Back...") { Width = 150 };

		protected void ShowRequestResult(string header, params string[] results)
		{
			responseSections.Add(new RequestResultSection(header, results));
		}

		protected void AddResponseSections(int row)
		{
			row++;
			foreach (var responseSection in responseSections)
			{
				if (Widgets.Contains(responseSection.Widgets.First())) continue; // skip already added sections

				responseSection.Collapse();

				AddSection(responseSection, ++row, 0);
				row += responseSection.RowCount;
			}
		}
	}
}
