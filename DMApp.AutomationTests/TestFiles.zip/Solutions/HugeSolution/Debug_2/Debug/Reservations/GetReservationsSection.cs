﻿namespace Debug_2.Debug.Reservations
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using Library.UI.Filters;
	using Skyline.DataMiner.DeveloperCommunityLibrary.InteractiveAutomationToolkit;
	using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;
	using Skyline.DataMiner.Library.Solutions.SRM;
	using Skyline.DataMiner.Net.Messages.SLDataGateway;
	using Skyline.DataMiner.Net.ResourceManager.Objects;

	public class GetReservationsSection : Section
	{
		private readonly Label header = new Label("Get Reservations with filters") { Style = TextStyle.Heading };

		private readonly FilterSection<ReservationInstance> reservationIdFilterSection = new GuidFilterSection<ReservationInstance>("Reservation ID", x => ReservationInstanceExposers.ID.Equal((Guid)x));

		private readonly FilterSection<ReservationInstance> reservationServiceDefinitionIdFilterSection = new GuidFilterSection<ReservationInstance>("Service Definition ID", x => ServiceReservationInstanceExposers.ServiceDefinitionID.Equal((Guid)x));

		private readonly FilterSection<ReservationInstance> reservationNameFilterSection = new StringFilterSection<ReservationInstance>("Reservation Name", x => ReservationInstanceExposers.Name.Equal((string)x));

		private readonly FilterSection<ReservationInstance> reservationStartFromFilterSection = new DateTimeFilterSection<ReservationInstance>("Reservation Start From", x => ReservationInstanceExposers.Start.GreaterThanOrEqual((DateTime)x));

		private readonly FilterSection<ReservationInstance> reservationStartUntilFilterSection = new DateTimeFilterSection<ReservationInstance>("Reservation Start Until", x => ReservationInstanceExposers.Start.LessThanOrEqual((DateTime)x));

		private readonly FilterSection<ReservationInstance> reservationEndFromFilterSection = new DateTimeFilterSection<ReservationInstance>("Reservation End From", x => ReservationInstanceExposers.End.GreaterThanOrEqual((DateTime)x));

		private readonly FilterSection<ReservationInstance> reservationEndUntilFilterSection = new DateTimeFilterSection<ReservationInstance>("Reservation End Until", x => ReservationInstanceExposers.End.LessThanOrEqual((DateTime)x));

		private readonly List<FilterSection<ReservationInstance>> propertyFilterSections = new List<FilterSection<ReservationInstance>>();

		private readonly Button addPropertyFilterButton = new Button("Add Property Filter");

		private readonly Button getSelectedReservationsButton = new Button("Get Selected Reservations") { Style = ButtonStyle.CallToAction };
		private readonly CollapseButton showSelectedReservationsButton;
		private readonly TextBox selectedReservationsTextBox = new TextBox() { IsMultiline = true, MinWidth = 500 };

		public GetReservationsSection()
		{
			addPropertyFilterButton.Pressed += AddPropertyFilterButton_Pressed;

			showSelectedReservationsButton = new CollapseButton(selectedReservationsTextBox.Yield(), true) { CollapseText = "Hide Selected Reservations", ExpandText = "Show Selected Reservations" };

			getSelectedReservationsButton.Pressed += (o, e) =>
			{
				SelectedReservations = GetSelectedReservations();
				ReservationsUpdated?.Invoke(this, SelectedReservations);
			};

			GenerateUi();
		}

		public IEnumerable<ReservationInstance> SelectedReservations { get; private set; } = new List<ReservationInstance>();

		public event EventHandler RegenerateUi;

		public event EventHandler<IEnumerable<ReservationInstance>> ReservationsUpdated;

		public void AddDefaultPropertyFilter(string propertyName, string propertyValue)
		{
			var propertyFilterSection = new PropertyFilterSection<ReservationInstance>("Property", (propName, propValue) => ReservationInstanceExposers.Properties.DictStringField((string)propName).Equal((string)propValue));

			propertyFilterSection.SetDefault(propertyName, propertyValue);

			propertyFilterSections.Add(propertyFilterSection);

			RegenerateUi?.Invoke(this, EventArgs.Empty);
		}

		public void GenerateUi()
		{
			Clear();

			int row = -1;

			AddWidget(header, ++row, 0, 1, 5);

			AddSection(reservationNameFilterSection, new SectionLayout(++row, 0));

			AddSection(reservationIdFilterSection, new SectionLayout(++row, 0));

			AddSection(reservationStartFromFilterSection, new SectionLayout(++row, 0));

			AddSection(reservationStartUntilFilterSection, new SectionLayout(++row, 0));

			AddSection(reservationEndFromFilterSection, new SectionLayout(++row, 0));

			AddSection(reservationEndUntilFilterSection, new SectionLayout(++row, 0));

			AddSection(reservationServiceDefinitionIdFilterSection, new SectionLayout(++row, 0));

			foreach (var propertyFilterSection in propertyFilterSections)
			{
				AddSection(propertyFilterSection, new SectionLayout(++row, 0));
			}

			AddWidget(addPropertyFilterButton, ++row, 0);

			AddWidget(new WhiteSpace(), ++row, 0);

			AddWidget(getSelectedReservationsButton, ++row, 0);
			AddWidget(showSelectedReservationsButton, row, 1);
			AddWidget(selectedReservationsTextBox, ++row, 1);
		}

		private void AddPropertyFilterButton_Pressed(object sender, EventArgs e)
		{
			var propertyFilterSection = new PropertyFilterSection<ReservationInstance>("Property", (propertyName, propertyValue) => ReservationInstanceExposers.Properties.DictStringField((string)propertyName).Equal((string)propertyValue));

			propertyFilterSections.Add(propertyFilterSection);

			RegenerateUi?.Invoke(this, EventArgs.Empty);
		}

		private IEnumerable<ReservationInstance> GetSelectedReservations()
		{
			selectedReservationsTextBox.Text = String.Empty;
			if (!this.ActiveFiltersAreValid<ReservationInstance>()) return new List<ReservationInstance>();

			FilterElement<ReservationInstance> defaultFilter = ReservationInstanceExposers.Name.NotEqual(String.Empty);
			var selectedReservations = SrmManagers.ResourceManager.GetReservationInstances(this.GetCombinedFilterElement<ReservationInstance>(defaultFilter)).ToList();

			selectedReservationsTextBox.Text = String.Join("\n", selectedReservations.Select(r => r.Name).OrderBy(name => name));

			return selectedReservations;
		}
	}
}
