﻿using System;
using System.Linq;
using Newtonsoft.Json;
using Skyline.DataMiner.DeveloperCommunityLibrary.InteractiveAutomationToolkit;
using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.DataMinerInterface;
using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.Debug;
using Skyline.DataMiner.DeveloperCommunityLibrary.YLE.Utilities;

namespace Debug_2.Debug.Reservations
{
	public class FindReservationsWithFiltersDialog : DebugDialog
	{
		private readonly GetReservationsSection getReservationsSection = new GetReservationsSection();

		private readonly Button showJsonButton = new Button("Show Reservations JSON");
		private readonly Button deleteButton = new Button("Delete Reservations");
		private readonly CheckBox deleteSafetyCheckbox = new CheckBox("Confirm Delete");
		private readonly Button getIdsButton = new Button("Get IDs");

		public FindReservationsWithFiltersDialog(Helpers helpers) : base(helpers)
		{
			Title = "Find Reservations with Filters";

			Initialize();
			GenerateUi();
		}

		private void Initialize()
		{
			getReservationsSection.RegenerateUi += GetReservationsSection_RegenerateUi;

			showJsonButton.Pressed += ShowJsonButton_Pressed;

			deleteButton.Pressed += DeleteButton_Pressed;

			getIdsButton.Pressed += GetIdsButton_Pressed;
		}

		private void GetIdsButton_Pressed(object sender, EventArgs e)
		{
			ShowRequestResult("Reservation IDs", string.Join("\n", getReservationsSection.SelectedReservations.Select(r => r.ID)));
			GenerateUi();
		}

		private void DeleteButton_Pressed(object sender, EventArgs e)
		{
			if (!deleteSafetyCheckbox.IsChecked) return;

			DataMinerInterface.ResourceManager.RemoveReservationInstances(helpers, getReservationsSection.SelectedReservations.ToArray());

			ShowRequestResult("Removed Reservations", string.Join("\n", getReservationsSection.SelectedReservations.Select(r => r.Name)));
			GenerateUi();
		}

		private void GetReservationsSection_RegenerateUi(object sender, EventArgs e)
		{
			getReservationsSection.GenerateUi();
			GenerateUi();
		}

		private void ShowJsonButton_Pressed(object sender, EventArgs e)
		{
			ShowRequestResult("Serialized Reservations", string.Join("\n", getReservationsSection.SelectedReservations.Select(r => JsonConvert.SerializeObject(r))));
			GenerateUi();
		}

		private void GenerateUi()
		{
			Clear();

			int row = -1;

			AddWidget(BackButton, ++row, 0, 1, 3);

			AddSection(getReservationsSection, new SectionLayout(++row, 0));
			row += getReservationsSection.RowCount;

			AddWidget(new WhiteSpace(), ++row, 0);
			AddWidget(showJsonButton, ++row, 0);
			AddWidget(deleteButton, ++row, 0);
			AddWidget(deleteSafetyCheckbox, row, 1);
			AddWidget(getIdsButton, ++row, 0);

			AddWidget(new WhiteSpace(), ++row, 0);

			AddResponseSections(row);
		}
	}
}
