﻿namespace Skyline.DataMiner.DeveloperCommunityLibrary.YLE.UI.Debug
{
	using Skyline.DataMiner.Utils.InteractiveAutomationScript;

	public abstract class ResponseSection : Section
	{
		public abstract void Collapse();
	}
}
