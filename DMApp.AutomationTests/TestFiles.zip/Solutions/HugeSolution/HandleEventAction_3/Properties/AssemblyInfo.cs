using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HandleEventAction_3")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Skyline Communications")]
[assembly: AssemblyProduct("HandleEventAction_3")]
[assembly: AssemblyCopyright("Copyright © Skyline Communications")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("35D81339-0949-4B82-9090-FF790B76E655")]
[assembly: AssemblyVersion("1.0.0.0")]
