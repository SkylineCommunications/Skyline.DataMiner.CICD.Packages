using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HandleNonLiveFolderDeletion_1")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Skyline Communications")]
[assembly: AssemblyProduct("HandleNonLiveFolderDeletion_1")]
[assembly: AssemblyCopyright("Copyright © Skyline Communications")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("445D1727-C131-49E6-B6FA-01A68D30C0E9")]
[assembly: AssemblyVersion("1.0.0.0")]
