using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DeleteUnusedReservations_1")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Skyline Communications")]
[assembly: AssemblyProduct("DeleteUnusedReservations_1")]
[assembly: AssemblyCopyright("Copyright © Skyline Communications")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("DF34DEF7-1B07-4821-A250-9117DD9C4914")]
[assembly: AssemblyVersion("1.0.0.0")]
