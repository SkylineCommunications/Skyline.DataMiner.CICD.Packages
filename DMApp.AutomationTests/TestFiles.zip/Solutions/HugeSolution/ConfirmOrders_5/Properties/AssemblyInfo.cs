using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ConfirmOrders_5")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Skyline Communications")]
[assembly: AssemblyProduct("ConfirmOrders_5")]
[assembly: AssemblyCopyright("Copyright © Skyline Communications")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("E1318018-211D-47C1-9A1A-35BDA7495AB5")]
[assembly: AssemblyVersion("1.0.0.0")]
