﻿This folder contains default templates to be used by the protocol.
Allowed names:
"Template_Alarm_Default.xml"
"Trending_Template_Default.xml"
"Information_Template_Default.xml"
