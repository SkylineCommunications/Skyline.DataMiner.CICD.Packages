﻿namespace SharedProject1
{
	public class Utility
	{
		public string ToUpper(string input)
		{
			return input.ToUpper();
		}
	}
}
