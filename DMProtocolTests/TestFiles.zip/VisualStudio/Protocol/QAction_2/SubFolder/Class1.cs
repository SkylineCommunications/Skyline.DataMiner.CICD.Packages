﻿namespace QAction_2.SubFolder
{
	public class SubfolderClass
	{
		public string Name { get; set; }
	}
}
